package pro.sketchware.activities.design;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.CompoundButton;

import pro.sketchware.activities.base.BaseAppCompatActivity;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;

import java.util.ArrayList;
import java.util.HashMap;

import pro.sketchware.core.project.ProguardHandler;
import pro.sketchware.util.library.ManageLocalLibrary;
import pro.sketchware.activities.editor.code.SrcCodeEditor;
import pro.sketchware.R;
import pro.sketchware.databinding.ManageProguardBinding;

public class ManageProguardActivity extends BaseAppCompatActivity
        implements View.OnClickListener, CompoundButton.OnCheckedChangeListener {

    private ProguardHandler proguardHandler;

    private ManageProguardBinding binding;

    @Override
    public void onClick(View v) {
        int id = v.getId();
        if (id == binding.lnPgRules.getId()) {
            Intent intent = new Intent(this, SrcCodeEditor.class);
            intent.putExtra("title", "proguard-rules.pro");
            intent.putExtra("content", proguardHandler.getCustomProguardRules());
            startActivity(intent);
        } else if (id == binding.lnPgFm.getId()) {
            fmDialog();
        }
    }

    private void fmDialog() {
        ManageLocalLibrary mll = new ManageLocalLibrary(getIntent().getStringExtra("sc_id"));

        String[] libraries = new String[mll.list.size()];
        boolean[] enabledLibraries = new boolean[mll.list.size()];

        for (int i = 0; i < mll.list.size(); i++) {
            HashMap<String, Object> current = mll.list.get(i);

            Object name = current.get("name");
            if (name instanceof String) {
                libraries[i] = (String) name;
                enabledLibraries[i] = proguardHandler.libIsProguardFMEnabled(libraries[i]);
            } else {
                libraries[i] = "(broken library configuration)";
                enabledLibraries[i] = false;
            }
        }

        MaterialAlertDialogBuilder bld = new MaterialAlertDialogBuilder(this);
        bld.setTitle(R.string.proguard_select_local_libs);
        bld.setMultiChoiceItems(
                libraries,
                enabledLibraries,
                (dialog, which, isChecked) -> enabledLibraries[which] = isChecked);
        bld.setPositiveButton(
                R.string.common_word_save,
                (dialog, which) -> {
                    ArrayList<String> finalList = new ArrayList<>();

                    for (int i = 0; i < libraries.length; i++) {
                        if (enabledLibraries[i]) {
                            finalList.add(libraries[i]);
                        }
                    }

                    proguardHandler.setProguardFMLibs(finalList);
                });
        bld.setNegativeButton(R.string.common_word_cancel, null);
        bld.create().show();
    }

    @Override
    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
        int id = buttonView.getId();
        if (id == binding.swPgEnabled.getId()) {
            proguardHandler.setProguardEnabled(isChecked);
        } else if (id == binding.r8Enabled.getId()) {
            proguardHandler.setR8Enabled(isChecked);
        } else if (id == binding.swPgDebug.getId()) {
            proguardHandler.setDebugEnabled(isChecked);
        }
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ManageProguardBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        initialize();
        initializeLogic();
    }

    private void initialize() {
        binding.swPgEnabled.setOnCheckedChangeListener(this);
        binding.lnPgRules.setOnClickListener(this);
        binding.r8Enabled.setOnCheckedChangeListener(this);
        binding.swPgDebug.setOnCheckedChangeListener(this);
        binding.lnPgFm.setOnClickListener(this);
    }

    private void initializeLogic() {
        _initToolbar();
        proguardHandler = new ProguardHandler(getIntent().getStringExtra("sc_id"));
        binding.swPgEnabled.setChecked(proguardHandler.isShrinkingEnabled());
        binding.swPgDebug.setChecked(proguardHandler.isDebugFilesEnabled());
        binding.r8Enabled.setChecked(proguardHandler.isR8Enabled());
    }

    private void _initToolbar() {
        binding.toolbar.setTitle(R.string.proguard_title);
        binding.toolbar.setNavigationOnClickListener(view -> getOnBackPressedDispatcher().onBackPressed());
    }
}
