package pro.sketchware.activities.editor.view;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.NinePatch;
import android.graphics.Rect;
import android.graphics.Typeface;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.NinePatchDrawable;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.util.Log;
import android.view.ContextThemeWrapper;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewOutlineProvider;
import android.view.ViewParent;
import android.widget.CalendarView;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.SeekBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.content.res.AppCompatResources;
import androidx.core.content.ContextCompat;
import androidx.appcompat.widget.AppCompatImageView;

import pro.sketchware.beans.ImageBean;
import pro.sketchware.beans.LayoutBean;
import pro.sketchware.beans.ProjectResourceBean;
import pro.sketchware.beans.ViewBean;
import pro.sketchware.util.library.Material3LibraryManager;
import pro.sketchware.activities.editor.view.item.ItemAdView;
import pro.sketchware.activities.editor.view.item.ItemBottomNavigationView;
import pro.sketchware.activities.editor.view.item.ItemButton;
import pro.sketchware.activities.editor.view.item.ItemCalendarView;
import pro.sketchware.activities.editor.view.item.ItemCardView;
import pro.sketchware.activities.editor.view.item.ItemCheckBox;
import pro.sketchware.activities.editor.view.item.ItemEditText;
import pro.sketchware.activities.editor.view.item.ItemFloatingActionButton;
import pro.sketchware.activities.editor.view.item.ItemHorizontalScrollView;
import pro.sketchware.activities.editor.view.item.ItemImageView;
import pro.sketchware.activities.editor.view.item.ItemLinearLayout;
import pro.sketchware.activities.editor.view.item.ItemListView;
import pro.sketchware.activities.editor.view.item.ItemMapView;
import pro.sketchware.activities.editor.view.item.ItemProgressBar;
import pro.sketchware.activities.editor.view.item.ItemRecyclerView;
import pro.sketchware.activities.editor.view.item.ItemRelativeLayout;
import pro.sketchware.activities.editor.view.item.ItemSearchView;
import pro.sketchware.activities.editor.view.item.ItemSeekBar;
import pro.sketchware.activities.editor.view.item.ItemSignInButton;
import pro.sketchware.activities.editor.view.item.ItemSpinner;
import pro.sketchware.activities.editor.view.item.ItemSwitch;
import pro.sketchware.activities.editor.view.item.ItemTabLayout;
import pro.sketchware.activities.editor.view.item.ItemTextView;
import pro.sketchware.activities.editor.view.item.ItemVerticalScrollView;
import pro.sketchware.activities.editor.view.item.ItemWebView;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.tabs.TabLayout;
import com.google.firebase.crashlytics.FirebaseCrashlytics;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import pro.sketchware.core.project.ClassInfo;
import pro.sketchware.core.project.ResourceManager;
import pro.sketchware.core.project.ProjectListManager;
import pro.sketchware.util.ViewUtil;
import pro.sketchware.core.project.SketchwarePaths;
import pro.sketchware.util.MapValueHelper;
import pro.sketchware.graphics.NinePatchDecoder;
import pro.sketchware.activities.editor.view.item.ItemBadgeView;
import pro.sketchware.activities.editor.view.item.ItemCircleImageView;
import pro.sketchware.activities.editor.view.item.ItemCodeView;
import pro.sketchware.activities.editor.view.item.ItemLottieAnimation;
import pro.sketchware.activities.editor.view.item.ItemMaterialButton;
import pro.sketchware.activities.editor.view.item.ItemOTPView;
import pro.sketchware.activities.editor.view.item.ItemPatternLockView;
import pro.sketchware.activities.editor.view.item.ItemViewPager;
import pro.sketchware.activities.editor.view.item.ItemWaveSideBar;
import pro.sketchware.activities.editor.view.item.ItemYoutubePlayer;
import pro.sketchware.beans.ViewBeans;
import pro.sketchware.activities.editor.view.item.ItemAnalogClock;
import pro.sketchware.activities.editor.view.item.ItemAutoCompleteTextView;
import pro.sketchware.activities.editor.view.item.ItemDatePicker;
import pro.sketchware.activities.editor.view.item.ItemDigitalClock;
import pro.sketchware.activities.editor.view.item.ItemGridView;
import pro.sketchware.activities.editor.view.item.ItemMultiAutoCompleteTextView;
import pro.sketchware.activities.editor.view.item.ItemRadioButton;
import pro.sketchware.activities.editor.view.item.ItemRatingBar;
import pro.sketchware.activities.editor.view.item.ItemTimePicker;
import pro.sketchware.activities.editor.view.item.ItemVideoView;
import pro.sketchware.graphics.VectorDrawableLoader;
import pro.sketchware.util.ProjectFile;
import pro.sketchware.util.LogUtil;
import pro.sketchware.R;
import pro.sketchware.core.resources.ColorResourceResolver;
import pro.sketchware.core.resources.StringResourceResolver;
import pro.sketchware.tools.InjectRootLayoutManager;
import pro.sketchware.util.FilePathUtil;
import pro.sketchware.util.FileUtil;
import pro.sketchware.util.InjectAttributeHandler;
import pro.sketchware.util.InvokeUtil;
import pro.sketchware.util.PropertiesUtil;
import pro.sketchware.util.SvgUtils;
import pro.sketchware.util.ThemeUtils;

public class ViewPane extends RelativeLayout {
    private final String stringsStart = "@string/";
    private final FirebaseCrashlytics crashlytics = getFirebaseCrashlytics();
    private Context context;
    private ViewGroup rootLayout;
    private int viewIdCounter = 99;
    private ArrayList<ViewInfo> viewInfos = new ArrayList<>();
    private ViewInfo viewInfo;
    private TextView highlightedTextView;
    private ResourceManager resourcesManager;
    private String sc_id;
    private SvgUtils svgUtils;
    private ColorResourceResolver colorResourceResolver;
    private int defaultTextColor = 0; // need to save the original color before changes, cause using getDefaultColor() returns the current text color
    private int defaultHintColor = 0;
    private Material3LibraryManager material3LibraryManager;
    private HashMap<String, String> xmlStringCache = null;
    private String xmlStringCacheScId = null;
    private HashMap<String, String> importedFontPathCache = null;
    private String importedFontPathCacheScId = null;

    public ViewPane(Context context) {
        super(context);
    }

    public ViewPane(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
    }

    public void clearViews() {
        resetView(true);
        viewInfos = new ArrayList<>();
        if (rootLayout != null) {
            ((ScrollContainer) rootLayout).setChildScrollEnabled(true);
        }
    }

    public void setResourceManager(ResourceManager resourcesManager) {
        this.resourcesManager = resourcesManager;
        invalidateImportedFontPathCache();
    }

    private void invalidateImportedFontPathCache() {
        importedFontPathCache = null;
        importedFontPathCacheScId = sc_id;
    }

    private void initTextView() {
        highlightedTextView = new TextView(getContext());
        highlightedTextView.setBackgroundResource(R.drawable.highlight);
        highlightedTextView.setLayoutParams(new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));
        highlightedTextView.setVisibility(GONE);
    }

    public void clearViewPane() {
        if (rootLayout != null) {
            rootLayout.removeAllViews();
        }
    }

    public void removeFabView() {
        View findViewWithTag = findViewWithTag("_fab");
        if (findViewWithTag == null) {
            return;
        }
        removeView(findViewWithTag);
    }

    public void removeView(ViewBean viewBean) {
        ViewGroup viewGroup = rootLayout.findViewWithTag(viewBean.parent);
        viewGroup.removeView(rootLayout.findViewWithTag(viewBean.id));
        if (viewGroup instanceof ScrollContainer) {
            ((ScrollContainer) viewGroup).reindexChildren();
        }
    }

    public ItemView updateView(ViewBean viewBean) {
        View findViewWithTag;
        String preId = viewBean.preId;
        if (preId != null && !preId.isEmpty() && !preId.equals(viewBean.id)) {
            View preView = rootLayout.findViewWithTag(preId);
            if (preView != null) preView.setTag(viewBean.id);
            viewBean.preId = "";
        }
        if (viewBean.id != null && !viewBean.id.isEmpty() && viewBean.id.charAt(0) == '_') {
            findViewWithTag = findViewWithTag(viewBean.id);
        } else {
            findViewWithTag = rootLayout.findViewWithTag(viewBean.id);
        }
        updateItemView(findViewWithTag, viewBean);
        return (ItemView) findViewWithTag;
    }

    public ItemView moveView(ViewBean viewBean) {
        View findViewWithTag = rootLayout.findViewWithTag(viewBean.id);
        if (viewBean.id != null && !viewBean.id.isEmpty() && viewBean.id.charAt(0) == '_') {
            findViewWithTag = findViewWithTag(viewBean.id);
        }
        String preParent = viewBean.preParent;
        if (preParent != null && !preParent.isEmpty() && !viewBean.parent.equals(viewBean.preParent)) {
            ViewGroup viewGroup = rootLayout.findViewWithTag(viewBean.preParent);
            viewGroup.removeView(findViewWithTag);
            ((ScrollContainer) viewGroup).reindexChildren();
            addViewAndUpdateIndex(findViewWithTag);
        } else if (viewBean.index != viewBean.preIndex) {
            ((ViewGroup) rootLayout.findViewWithTag(viewBean.parent)).removeView(findViewWithTag);
            addViewAndUpdateIndex(findViewWithTag);
        }
        viewBean.preId = "";
        viewBean.preIndex = -1;
        viewBean.preParent = "";
        viewBean.preParentType = -1;
        findViewWithTag.setVisibility(VISIBLE);
        return (ItemView) findViewWithTag;
    }

    public void initialize(String sc_id, boolean isPreviewMode) {
        this.sc_id = sc_id;
        if (importedFontPathCacheScId == null || !importedFontPathCacheScId.equals(sc_id)) {
            invalidateImportedFontPathCache();
        }
        material3LibraryManager = new Material3LibraryManager(getContext(), sc_id);
        colorResourceResolver = new ColorResourceResolver(sc_id);
        int viewEditorThemeOverlay = material3LibraryManager.getViewEditorThemeOverlay();
        context = new ContextThemeWrapper(getContext(), viewEditorThemeOverlay);
        svgUtils = new SvgUtils(context);
        svgUtils.initImageLoader();
        if (viewEditorThemeOverlay == R.style.ThemeOverlay_SketchwarePro_ViewEditor) {
            setBackgroundColor(Color.WHITE);
        } else if (isPreviewMode) {
            setBackgroundColor(ThemeUtils.getColor(context, R.attr.colorSurface));
        } else {
            setBackground(AppCompatResources.getDrawable(context, R.drawable.bg_view_pane));
        }
        //addRootLayout();
        initTextView();
    }

    public void addRootLayout(ViewBean viewBean) {
        viewInfo = null;
        if (rootLayout != null) {
            if (rootLayout instanceof ItemLinearLayout linearLayout) {
                addDroppableForLinearLayout(viewBean, linearLayout);
            } else {
                addDroppableForViewGroup(viewBean, rootLayout);
            }
            ((ScrollContainer) rootLayout).setChildScrollEnabled(false);
        }
    }

    private int calculateViewDepth(View view) {
        View currentView = view;
        int depth = 0;
        while (currentView != null && currentView != rootLayout) {
            depth++;
            currentView = (View) currentView.getParent();
        }
        return depth * 2;
    }

    public View createItemView(ViewBean viewBean) {
        View item = switch (viewBean.type) {
            case ViewBean.VIEW_TYPE_LAYOUT_LINEAR,
                 ViewBeans.VIEW_TYPE_LAYOUT_COLLAPSINGTOOLBARLAYOUT,
                 ViewBeans.VIEW_TYPE_LAYOUT_TEXTINPUTLAYOUT,
                 ViewBeans.VIEW_TYPE_LAYOUT_SWIPEREFRESHLAYOUT,
                 ViewBeans.VIEW_TYPE_LAYOUT_RADIOGROUP -> new ItemLinearLayout(context);
            case ViewBean.VIEW_TYPE_LAYOUT_RELATIVE -> new ItemRelativeLayout(context);
            case ViewBeans.VIEW_TYPE_LAYOUT_CARDVIEW -> new ItemCardView(context);
            case ViewBean.VIEW_TYPE_LAYOUT_HSCROLLVIEW -> new ItemHorizontalScrollView(context);
            case ViewBean.VIEW_TYPE_WIDGET_BUTTON -> new ItemButton(context);
            case ViewBean.VIEW_TYPE_WIDGET_TEXTVIEW -> new ItemTextView(context);
            case ViewBean.VIEW_TYPE_WIDGET_EDITTEXT -> new ItemEditText(context);
            case ViewBean.VIEW_TYPE_WIDGET_IMAGEVIEW -> new ItemImageView(context);
            case ViewBean.VIEW_TYPE_WIDGET_WEBVIEW -> new ItemWebView(context);
            case ViewBean.VIEW_TYPE_WIDGET_PROGRESSBAR -> new ItemProgressBar(context);
            case ViewBean.VIEW_TYPE_WIDGET_LISTVIEW -> new ItemListView(context);
            case ViewBean.VIEW_TYPE_WIDGET_SPINNER -> new ItemSpinner(context);
            case ViewBean.VIEW_TYPE_WIDGET_CHECKBOX -> new ItemCheckBox(context);
            case ViewBean.VIEW_TYPE_LAYOUT_VSCROLLVIEW -> new ItemVerticalScrollView(context);
            case ViewBean.VIEW_TYPE_WIDGET_SWITCH -> new ItemSwitch(context);
            case ViewBean.VIEW_TYPE_WIDGET_SEEKBAR -> new ItemSeekBar(context);
            case ViewBean.VIEW_TYPE_WIDGET_CALENDARVIEW -> new ItemCalendarView(context);
            case ViewBean.VIEW_TYPE_WIDGET_ADVIEW -> new ItemAdView(context);
            case ViewBean.VIEW_TYPE_WIDGET_MAPVIEW -> new ItemMapView(context);
            case ViewBeans.VIEW_TYPE_WIDGET_RADIOBUTTON -> new ItemRadioButton(context);
            case ViewBeans.VIEW_TYPE_WIDGET_RATINGBAR -> new ItemRatingBar(context);
            case ViewBeans.VIEW_TYPE_WIDGET_VIDEOVIEW -> new ItemVideoView(context);
            case ViewBeans.VIEW_TYPE_WIDGET_SEARCHVIEW -> new ItemSearchView(context);
            case ViewBeans.VIEW_TYPE_WIDGET_AUTOCOMPLETETEXTVIEW ->
                    new ItemAutoCompleteTextView(context);
            case ViewBeans.VIEW_TYPE_WIDGET_MULTIAUTOCOMPLETETEXTVIEW ->
                    new ItemMultiAutoCompleteTextView(context);
            case ViewBeans.VIEW_TYPE_WIDGET_GRIDVIEW -> new ItemGridView(context);
            case ViewBeans.VIEW_TYPE_WIDGET_ANALOGCLOCK -> new ItemAnalogClock(context);
            case ViewBeans.VIEW_TYPE_WIDGET_DATEPICKER -> new ItemDatePicker(context);
            case ViewBeans.VIEW_TYPE_WIDGET_TIMEPICKER -> new ItemTimePicker(context);
            case ViewBeans.VIEW_TYPE_WIDGET_DIGITALCLOCK -> new ItemDigitalClock(context);
            case ViewBeans.VIEW_TYPE_LAYOUT_TABLAYOUT -> new ItemTabLayout(context);
            case ViewBeans.VIEW_TYPE_LAYOUT_VIEWPAGER -> new ItemViewPager(context);
            case ViewBeans.VIEW_TYPE_LAYOUT_BOTTOMNAVIGATIONVIEW ->
                    new ItemBottomNavigationView(context);
            case ViewBeans.VIEW_TYPE_WIDGET_BADGEVIEW -> new ItemBadgeView(context);
            case ViewBeans.VIEW_TYPE_WIDGET_PATTERNLOCKVIEW -> new ItemPatternLockView(context);
            case ViewBeans.VIEW_TYPE_WIDGET_WAVESIDEBAR -> new ItemWaveSideBar(context);
            case ViewBeans.VIEW_TYPE_WIDGET_MATERIALBUTTON -> new ItemMaterialButton(context);
            case ViewBeans.VIEW_TYPE_WIDGET_SIGNINBUTTON -> new ItemSignInButton(context);
            case ViewBeans.VIEW_TYPE_WIDGET_CIRCLEIMAGEVIEW -> new ItemCircleImageView(context);
            case ViewBeans.VIEW_TYPE_WIDGET_LOTTIEANIMATIONVIEW -> new ItemLottieAnimation(context);
            case ViewBeans.VIEW_TYPE_WIDGET_YOUTUBEPLAYERVIEW -> new ItemYoutubePlayer(context);
            case ViewBeans.VIEW_TYPE_WIDGET_OTPVIEW -> new ItemOTPView(context);
            case ViewBeans.VIEW_TYPE_WIDGET_CODEVIEW -> new ItemCodeView(context);
            case ViewBeans.VIEW_TYPE_WIDGET_RECYCLERVIEW -> new ItemRecyclerView(context);
            default -> getUnknownItemView(viewBean);
        };
        item.setId(++viewIdCounter);
        item.setTag(viewBean.id);
        ((ItemView) item).setBean(viewBean);
        updateItemView(item, viewBean);
        return item;
    }

    private View getUnknownItemView(ViewBean bean) {
        LogUtil.w("ViewPane", "Unknown widget type " + bean.type + " for view '" + bean.id + "'; showing as LinearLayout placeholder");
        return new ItemLinearLayout(context);
    }

    public void updateRootLayout(String sc_id, String fileName) {
        InjectRootLayoutManager manager = new InjectRootLayoutManager(sc_id);
        var currentBean = manager.toBean(fileName);
        View rootView = createItemView(currentBean);
        if (rootView instanceof ItemView sy) {
            sy.setFixed(true);
        }
        if (rootLayout != null) {
            removeView(rootLayout);
        } else {
            rootLayout = (ViewGroup) rootView;
        }
        if (rootLayout instanceof ItemView sy) {
            if (!currentBean.isEqual(sy.getBean())) {
                rootLayout = (ViewGroup) rootView;
            }
        }
        addView(rootLayout);
    }

    private void updateItemView(View view, ViewBean viewBean) {
        ImageBean imageBean;
        String resName;
        var injectHandler = new InjectAttributeHandler(viewBean);
        if (viewBean.id != null && !viewBean.id.isEmpty() && viewBean.id.charAt(0) == '_') {
            LayoutParams layoutParams = new LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT);
            layoutParams.leftMargin = (int) ViewUtil.dpToPx(getContext(), (float) viewBean.layout.marginLeft);
            layoutParams.topMargin = (int) ViewUtil.dpToPx(getContext(), (float) viewBean.layout.marginTop);
            layoutParams.rightMargin = (int) ViewUtil.dpToPx(getContext(), (float) viewBean.layout.marginRight);
            layoutParams.bottomMargin = (int) ViewUtil.dpToPx(getContext(), (float) viewBean.layout.marginBottom);
            int layoutGravity = viewBean.layout.layoutGravity;
            if ((layoutGravity & Gravity.LEFT) == Gravity.LEFT) {
                layoutParams.addRule(RelativeLayout.ALIGN_PARENT_LEFT);
            }
            if ((layoutGravity & Gravity.TOP) == Gravity.TOP) {
                layoutParams.addRule(RelativeLayout.ALIGN_PARENT_TOP);
            }
            if ((layoutGravity & Gravity.RIGHT) == Gravity.RIGHT) {
                layoutParams.addRule(RelativeLayout.ALIGN_PARENT_RIGHT);
            }
            if ((layoutGravity & Gravity.BOTTOM) == Gravity.BOTTOM) {
                layoutParams.addRule(RelativeLayout.ALIGN_PARENT_BOTTOM);
            }
            if ((layoutGravity & Gravity.CENTER_HORIZONTAL) == Gravity.CENTER_HORIZONTAL) {
                layoutParams.addRule(RelativeLayout.CENTER_HORIZONTAL);
            }
            if ((layoutGravity & Gravity.CENTER_VERTICAL) == Gravity.CENTER_VERTICAL) {
                layoutParams.addRule(RelativeLayout.CENTER_VERTICAL);
            }
            if ((layoutGravity & Gravity.CENTER) == Gravity.CENTER) {
                layoutParams.addRule(RelativeLayout.CENTER_IN_PARENT);
            }
            view.setLayoutParams(layoutParams);
            if (viewBean.getClassInfo().isExactType("FloatingActionButton") && (imageBean = viewBean.image) != null && (resName = imageBean.resName) != null && !resName.isEmpty()) {
                try {
                    if (crashlytics != null) crashlytics.log("ViewPane: trying to set image to FAB");
                    FloatingActionButton fab = (FloatingActionButton) view;
                    if (resourcesManager.getImageResType(viewBean.image.resName) == ProjectResourceBean.PROJECT_RES_TYPE_RESOURCE) {
                        int resourceId = getContext().getResources().getIdentifier(viewBean.image.resName, "drawable", getContext().getPackageName());
                        if (resourceId != 0) {
                            fab.setImageResource(resourceId);
                        }
                    } else if (viewBean.image.resName.equals("default_image")) {
                        fab.setImageResource(R.drawable.default_image);
                    } else {
                        String imagePath = resourcesManager.getImagePath(viewBean.image.resName);
                        if (imagePath == null) return;
                        File imageFile = new File(imagePath);

                        if (imageFile.exists()) {
                            int scaleFactor = Math.round(getResources().getDisplayMetrics().density / 2.0f);

                            if (imagePath.endsWith(".xml")) {
                                if (crashlytics != null) crashlytics.log("ViewPane: loading scaled XML/SVG image");
                                FilePathUtil fpu = new FilePathUtil();
                                svgUtils.loadScaledSvgIntoImageView(new AppCompatImageView(getContext()) {
                                    @Override
                                    public void setImageBitmap(Bitmap bitmap) {
                                        fab.setImageBitmap(bitmap);
                                    }
                                }, fpu.getSvgFullPath(sc_id, viewBean.image.resName), scaleFactor);
                            } else {
                                Bitmap bitmap = FileUtil.decodeSampleBitmapFromPath(imagePath, 256, 256);
                                if (bitmap != null) {
                                    fab.setImageBitmap(bitmap);
                                }
                            }
                        } else {
                            if (crashlytics != null) crashlytics.log("ViewPane: converting XML to SVG for FAB");
                            VectorDrawableLoader vectorDrawableLoader = new VectorDrawableLoader();
                            ImageView tempImageView = new AppCompatImageView(getContext()) {
                                @Override
                                public void setImageDrawable(Drawable drawable) {
                                    fab.setImageDrawable(drawable);
                                }
                            };
                            vectorDrawableLoader.setImageVectorFromFile(tempImageView, vectorDrawableLoader.getVectorFullPath(sc_id, viewBean.image.resName), sc_id);
                        }
                    }
                } catch (Exception exception) {
                    if (crashlytics != null) crashlytics.recordException(exception);
                }
            }
            view.setRotation(viewBean.image.rotate);
            view.setAlpha(viewBean.alpha);
            view.setTranslationX(ViewUtil.dpToPx(getContext(), viewBean.translationX));
            view.setTranslationY(ViewUtil.dpToPx(getContext(), viewBean.translationY));
            view.setScaleX(viewBean.scaleX);
            view.setScaleY(viewBean.scaleY);
            applyElevation(view, resolvePreviewElevation(injectHandler, viewBean.layout.elevation));
            view.setVisibility(View.VISIBLE);
            return;
        }
        updateLayout(view, viewBean);
        view.setRotation(viewBean.image.rotate);
        view.setAlpha(viewBean.alpha);
        view.setTranslationX(ViewUtil.dpToPx(getContext(), viewBean.translationX));
        view.setTranslationY(ViewUtil.dpToPx(getContext(), viewBean.translationY));
        view.setScaleX(viewBean.scaleX);
        view.setScaleY(viewBean.scaleY);
        String backgroundResource = viewBean.layout.backgroundResource;
        if (backgroundResource != null) {
            try {
                if (resourcesManager.getImageResType(backgroundResource) == ProjectResourceBean.PROJECT_RES_TYPE_RESOURCE) {
                    int bgResId = getContext().getResources().getIdentifier(viewBean.layout.backgroundResource, "drawable", getContext().getPackageName());
                    if (bgResId != 0) {
                        view.setBackgroundResource(bgResId);
                    }
                } else {
                    String backgroundRes = resourcesManager.getImagePath(viewBean.layout.backgroundResource);
                    if (backgroundRes != null && new File(backgroundRes).exists()) {
                        if (backgroundRes.endsWith(".9.png")) {
                            Bitmap decodedBitmap = NinePatchDecoder.decodeFile(backgroundRes);
                            if (decodedBitmap != null) {
                                byte[] ninePatchChunk = decodedBitmap.getNinePatchChunk();
                                if (NinePatch.isNinePatchChunk(ninePatchChunk)) {
                                    view.setBackground(new NinePatchDrawable(getResources(), decodedBitmap, ninePatchChunk, new Rect(), null));
                                } else {
                                    view.setBackground(new BitmapDrawable(getResources(), backgroundRes));
                                }
                            }
                        } else {
                            Bitmap bgBitmap = FileUtil.decodeSampleBitmapFromPath(backgroundRes, 512, 512);
                            if (bgBitmap != null) {
                                view.setBackground(new BitmapDrawable(getResources(), bgBitmap));
                            }
                        }
                    }
                }
            } catch (Exception e) {
                Log.e("ViewPane", e.getMessage(), e);
            }
        }
        ClassInfo classInfo = viewBean.getClassInfo();
        if (classInfo.matchesType("LinearLayout")) {
            LinearLayout linearLayout = (LinearLayout) view;
            linearLayout.setOrientation(viewBean.layout.orientation);
            linearLayout.setWeightSum(viewBean.layout.weightSum);
            if (view instanceof ItemLinearLayout) {
                ((ItemLinearLayout) view).setLayoutGravity(viewBean.layout.gravity);
            }
        }
        if (viewBean.parentType == ViewBean.VIEW_TYPE_LAYOUT_RELATIVE) {
            updateRelative(view, injectHandler);
        }
        if (classInfo.matchesType("TextView")) {
            TextView textView = (TextView) view;
            updateTextView(textView, viewBean);
            if (!classInfo.isExactType("Button") && !classInfo.isExactType("Switch")) {
                textView.setGravity(viewBean.layout.gravity);
            } else {
                int gravity = viewBean.layout.gravity;
                if (gravity == LayoutBean.GRAVITY_NONE) {
                    textView.setGravity(Gravity.CENTER);
                } else {
                    textView.setGravity(gravity);
                }
            }
        }
        if (classInfo.matchesType("EditText")) {
            updateEditText((EditText) view, viewBean);
        }
        if (classInfo.matchesType("ImageView")) {
            String imgResName = viewBean.image.resName;
            if (TextUtils.isEmpty(imgResName) || "NONE".equalsIgnoreCase(imgResName)) {
                ((ImageView) view).setImageResource(R.drawable.default_image);
            } else if (resourcesManager.getImageResType(imgResName) == ProjectResourceBean.PROJECT_RES_TYPE_RESOURCE) {
                int imgResId = getContext().getResources().getIdentifier(imgResName, "drawable", getContext().getPackageName());
                if (imgResId != 0) {
                    ((ImageView) view).setImageResource(imgResId);
                }
            } else if ("default_image".equals(imgResName)) {
                ((ImageView) view).setImageResource(R.drawable.default_image);
            } else {
                try {
                    String imagelocation = resourcesManager.getImagePath(imgResName);
                    if (imagelocation != null) {
                        File file = new File(imagelocation);
                        if (file.exists() && file.length() > 0) {
                            int imageScale = Math.round(getResources().getDisplayMetrics().density / 2.0f);
                            if (imagelocation.endsWith(".xml")) {
                                FilePathUtil fpu = new FilePathUtil();
                                svgUtils.loadScaledSvgIntoImageView((ImageView) view, fpu.getSvgFullPath(sc_id, imgResName), imageScale);
                            } else {
                                Bitmap imageBitmap = FileUtil.decodeSampleBitmapFromPath(imagelocation, 512, 512);
                                if (imageBitmap != null) {
                                    ((ImageView) view).setImageBitmap(imageBitmap);
                                }
                            }
                        } else {
                            VectorDrawableLoader vectorDrawableLoader = new VectorDrawableLoader();
                            vectorDrawableLoader.setImageVectorFromFile((ImageView) view, vectorDrawableLoader.getVectorFullPath(sc_id, imgResName), sc_id);
                        }
                    }
                } catch (Exception vectorException) {
                    if (crashlytics != null) crashlytics.recordException(vectorException);
                    FileUtil.deleteFile(new VectorDrawableLoader().getVectorFullPath(sc_id, imgResName));
                    viewBean.image.resName = "default_image";
                    ((ImageView) view).setImageResource(R.drawable.default_image);
                }
            }
            if (classInfo.isExactType("CircleImageView")) {
                updateCircleImageView((ItemCircleImageView) view, injectHandler);
            } else {
                String scaleTypeName = viewBean.image.scaleType;
                if (TextUtils.isEmpty(scaleTypeName)) {
                    scaleTypeName = ImageBean.SCALE_TYPE_CENTER;
                }
                try {
                    ((ImageView) view).setScaleType(ImageView.ScaleType.valueOf(scaleTypeName));
                } catch (IllegalArgumentException ignored) {
                    ((ImageView) view).setScaleType(ImageView.ScaleType.CENTER);
                }
            }
        }
        if (classInfo.matchesType("CompoundButton")) {
            ((CompoundButton) view).setChecked(viewBean.checked != 0);
        }
        if (classInfo.isExactType("SeekBar")) {
            SeekBar seekBar = (SeekBar) view;
            seekBar.setProgress(viewBean.progress);
            seekBar.setMax(viewBean.max);
        }
        if (classInfo.isExactType("ProgressBar")) {
            ((ItemProgressBar) view).setProgressBarStyle(viewBean.progressStyle);
        }
        if (classInfo.isExactType("CalendarView")) {
            ((CalendarView) view).setFirstDayOfWeek(viewBean.firstDayOfWeek);
        }
        if (classInfo.isExactType("AdView")) {
            ((ItemAdView) view).setAdSize(viewBean.adSize);
        }
        if (classInfo.isExactType("CardView")) {
            var cardView = (ItemCardView) view;
            cardView.setContentPadding(
                    viewBean.layout.paddingLeft,
                    viewBean.layout.paddingTop,
                    viewBean.layout.paddingRight,
                    viewBean.layout.paddingBottom);
            updateCardView(cardView, injectHandler);
        }
        if (classInfo.isExactType("TabLayout")) {
            updateTabLayout((ItemTabLayout) view, injectHandler);
        }
        if (classInfo.isExactType("MaterialButton")) {
            updateMaterialButton((ItemMaterialButton) view, injectHandler);
        }
        if (classInfo.isExactType("SignInButton")) {
            ItemSignInButton button = (ItemSignInButton) view;
            boolean hasButtonSize = false;
            boolean hasColorScheme = false;
            for (String line : viewBean.inject.split("\n")) {
                if (line.contains("buttonSize")) {
                    String buttonSize = extractAttrValue(line, "app:buttonSize");
                    if (!buttonSize.startsWith("@")) {
                        hasButtonSize = true;
                        switch (buttonSize) {
                            case "icon_only":
                                button.setSize(ItemSignInButton.ButtonSize.ICON_ONLY);
                                break;
                            case "wide":
                                button.setSize(ItemSignInButton.ButtonSize.WIDE);
                                break;
                            case "standard":
                            default:
                                button.setSize(ItemSignInButton.ButtonSize.STANDARD);
                                break;
                        }
                    }
                }
                if (line.contains("colorScheme")) {
                    String colorScheme = extractAttrValue(line, "app:colorScheme");
                    if (!colorScheme.startsWith("@")) {
                        hasColorScheme = true;
                        switch (colorScheme) {
                            case "dark":
                                button.setColorScheme(ItemSignInButton.ColorScheme.DARK);
                                break;
                            case "auto":
                            case "light":
                            default:
                                button.setColorScheme(ItemSignInButton.ColorScheme.LIGHT);
                                break;
                        }
                    }
                }
            }
            if (!hasButtonSize) button.setSize(ItemSignInButton.ButtonSize.STANDARD);
            if (!hasColorScheme) button.setColorScheme(ItemSignInButton.ColorScheme.LIGHT);
        }
        if (!classInfo.isExactType("CardView")) {
            applyElevation(view, resolvePreviewElevation(injectHandler, viewBean.layout.elevation));
        }
        view.setVisibility(VISIBLE);
        if (view instanceof EditorListItem listItem) {
            String listitem = injectHandler.getAttributeValueOf("listitem");
            String itemCount = injectHandler.getAttributeValueOf("itemCount");
            if (!TextUtils.isEmpty(listitem)) {
                listItem.setListItem(android.R.layout.simple_list_item_1);
            }
            if (crashlytics != null) crashlytics.log("ViewPane: setting item count to EditorListItem");
            if (!TextUtils.isEmpty(itemCount)) {
                if (TextUtils.isEmpty(listitem)) {
                    try {
                        listItem.setItemCount(Integer.parseInt(itemCount));
                    } catch (NumberFormatException exception) {
                        if (crashlytics != null) crashlytics.recordException(exception);
                    }
                }
            }
        }
    }

    public ItemView findItemViewByTag(String tag) {
        if (tag == null || tag.isEmpty()) {
            return null;
        }
        View findViewWithTag = null;
        if (tag.charAt(0) == '_') {
            findViewWithTag = findViewWithTag(tag);
        } else {
            if (rootLayout != null) {
                findViewWithTag = rootLayout.findViewWithTag(tag);
            }
        }
        if (findViewWithTag instanceof ItemView) {
            return (ItemView) findViewWithTag;
        }
        return null;
    }

    public void updateViewBeanProperties(ViewBean viewBean, int index, int depth) {
        if (viewInfo != null) {
            View view = viewInfo.view();
            if (view instanceof LinearLayout) {
                viewBean.preIndex = viewBean.index;
                viewBean.index = viewInfo.index();
                viewBean.preParent = viewBean.parent;
                viewBean.parent = view.getTag() != null ? view.getTag().toString() : "";
                viewBean.preParentType = viewBean.parentType;
                viewBean.parentType = ViewBean.VIEW_TYPE_LAYOUT_LINEAR;
            } else if (view instanceof ItemVerticalScrollView) {
                viewBean.preIndex = viewBean.index;
                viewBean.index = viewInfo.index();
                viewBean.preParent = viewBean.parent;
                viewBean.parent = view.getTag() != null ? view.getTag().toString() : "";
                viewBean.preParentType = viewBean.parentType;
                viewBean.parentType = ViewBean.VIEW_TYPE_LAYOUT_VSCROLLVIEW;
                viewBean.layout.height = ViewGroup.LayoutParams.WRAP_CONTENT;
            } else if (view instanceof ItemHorizontalScrollView) {
                viewBean.preIndex = viewBean.index;
                viewBean.index = viewInfo.index();
                viewBean.preParent = viewBean.parent;
                viewBean.parent = view.getTag() != null ? view.getTag().toString() : "";
                viewBean.preParentType = viewBean.parentType;
                viewBean.parentType = ViewBean.VIEW_TYPE_LAYOUT_HSCROLLVIEW;
                viewBean.layout.width = ViewGroup.LayoutParams.WRAP_CONTENT;
            } else if (view instanceof ItemCardView) {
                viewBean.preIndex = viewBean.index;
                viewBean.index = viewInfo.index();
                viewBean.preParent = viewBean.parent;
                viewBean.parent = view.getTag() != null ? view.getTag().toString() : "";
                viewBean.preParentType = viewBean.parentType;
                viewBean.parentType = ViewBeans.VIEW_TYPE_LAYOUT_CARDVIEW;
                viewBean.layout.width = ViewGroup.LayoutParams.MATCH_PARENT;
            } else if (view instanceof ItemRelativeLayout) {
                viewBean.preIndex = viewBean.index;
                viewBean.index = viewInfo.index();
                viewBean.preParent = viewBean.parent;
                viewBean.parent = view.getTag() != null ? view.getTag().toString() : "";
                viewBean.preParentType = viewBean.parentType;
                viewBean.parentType = ViewBean.VIEW_TYPE_LAYOUT_RELATIVE;
            }
        } else {
            viewBean.preIndex = viewBean.index;
            viewBean.preParent = viewBean.parent;
            viewBean.parent = "root";
            viewBean.preParentType = viewBean.parentType;
            if (rootLayout instanceof ItemView sy) {
                viewBean.parentType = sy.getBean().type;
            } else {
                viewBean.parentType = ViewBean.VIEW_TYPE_LAYOUT_LINEAR;
            }
            viewBean.index = -1;
        }
    }

    public View addFab(ViewBean viewBean) {
        View findViewWithTag = findViewWithTag("_fab");
        if (findViewWithTag != null) {
            return findViewWithTag;
        }
        ItemFloatingActionButton itemFloatingActionButton = new ItemFloatingActionButton(context);
        itemFloatingActionButton.setTag("_fab");
        itemFloatingActionButton.setLayoutParams(new LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));
        itemFloatingActionButton.setMainColor(ProjectFile.getColor(sc_id, ProjectFile.COLOR_ACCENT));
        itemFloatingActionButton.setFixed(true);
        if (viewBean == null) {
            ViewBean defaultFabBean = new ViewBean("_fab", ViewBean.VIEW_TYPE_WIDGET_FAB);
            LayoutBean layoutBean = defaultFabBean.layout;
            layoutBean.marginLeft = 16;
            layoutBean.marginTop = 16;
            layoutBean.marginRight = 16;
            layoutBean.marginBottom = 16;
            layoutBean.layoutGravity = Gravity.RIGHT | Gravity.BOTTOM;
            itemFloatingActionButton.setBean(defaultFabBean);
        } else {
            itemFloatingActionButton.setBean(viewBean);
        }
        addView(itemFloatingActionButton);
        updateItemView(itemFloatingActionButton, itemFloatingActionButton.getBean());
        return itemFloatingActionButton;
    }

    public void resetView(boolean shouldClearViewInfo) {
        highlightedTextView.setVisibility(View.GONE);
        ViewParent parent = highlightedTextView.getParent();
        if (parent != null) {
            ((ViewGroup) parent).removeView(highlightedTextView);
        }
        if (shouldClearViewInfo) {
            viewInfo = null;
        }
    }

    public void updateView(int x, int y, int width, int height) {
        ViewInfo viewInfo = getViewInfo(x, y);
        if (viewInfo == null) {
            resetView(true);
        } else if (this.viewInfo != viewInfo) {
            resetView(true);
            ViewGroup viewGroup = (ViewGroup) viewInfo.view();
            viewGroup.addView(highlightedTextView, viewInfo.index());
            if (viewGroup instanceof LinearLayout) {
                highlightedTextView.setLayoutParams(new LinearLayout.LayoutParams(width, height));
            } else if (viewGroup instanceof FrameLayout) {
                highlightedTextView.setLayoutParams(new FrameLayout.LayoutParams(width, height));
            } else {
                highlightedTextView.setLayoutParams(new LayoutParams(width, height));
            }
            highlightedTextView.setVisibility(View.VISIBLE);
            this.viewInfo = viewInfo;
        }
    }

    private ViewInfo getViewInfo(int x, int y) {
        ViewInfo result = null;
        int highestPriority = -1;
        for (ViewInfo viewInfo : viewInfos) {
            if (viewInfo.rect().contains(x, y) && highestPriority < viewInfo.depth()) {
                highestPriority = viewInfo.depth();
                result = viewInfo;
            }
        }
        return result;
    }

    private void addDroppableForLinearLayout(ViewBean view, ItemLinearLayout linearLayout) {
        float scaleX = getScaleX();
        float scaleY = getScaleY();
        int[] locationOnScreen = new int[2];
        linearLayout.getLocationOnScreen(locationOnScreen);
        int layoutGravity = linearLayout.getLayoutGravity();
        int horizontalGravity = layoutGravity & Gravity.FILL_HORIZONTAL;
        int verticalGravity = layoutGravity & Gravity.FILL_VERTICAL;
        Rect parentRect = new Rect(locationOnScreen[0], locationOnScreen[1], (int) (linearLayout.getWidth() * getScaleX()) + locationOnScreen[0], (int) (linearLayout.getHeight() * getScaleY()) + locationOnScreen[1]);
        addViewInfo(parentRect, linearLayout, -1, calculateViewDepth(linearLayout));

        int parentWidth = (int) (linearLayout.getMeasuredWidth() * scaleX);
        int parentHeight = (int) (linearLayout.getMeasuredHeight() * scaleY);
        int paddingLeft = parentRect.left + (int) (linearLayout.getPaddingLeft() * scaleX);
        int paddingTop = parentRect.top + (int) (linearLayout.getPaddingTop() * scaleY);

        int childIndex = 0;
        for (int i = 0; i < linearLayout.getChildCount(); i++) {
            View child = linearLayout.getChildAt(i);
            if (child != null && child.getTag() != null && (view == null || view.id == null || !child.getTag().equals(view.id)) && child.getVisibility() == View.VISIBLE) {
                int[] childLocationOnScreen = new int[2];
                linearLayout.getLocationOnScreen(childLocationOnScreen);
                Rect childRect = new Rect();
                var layoutParams = (LinearLayout.LayoutParams) child.getLayoutParams();
                int leftMargin = layoutParams.leftMargin;
                int rightMargin = layoutParams.rightMargin;
                int topMargin = layoutParams.topMargin;
                int bottomMargin = layoutParams.bottomMargin;
                int childWidth = (int) (child.getMeasuredWidth() * linearLayout.getScaleX());
                int childHeight = (int) (child.getMeasuredHeight() * linearLayout.getScaleY());
                if (linearLayout.getOrientation() == LinearLayout.VERTICAL) {
                    if (verticalGravity == Gravity.CENTER_VERTICAL) {
                        int childTopY;
                        if (i == 0) {
                            childTopY = childLocationOnScreen[1] - (int) (topMargin * scaleY);
                            int parentLeft = parentRect.left;
                            addViewInfo(
                                    new Rect(
                                            parentLeft,
                                            paddingTop,
                                            parentWidth + parentLeft,
                                            childTopY),
                                    linearLayout,
                                    0,
                                    calculateViewDepth(linearLayout) + 1);
                        } else {
                            childTopY = paddingTop;
                        }
                        paddingTop =
                                (int) ((topMargin + childHeight + bottomMargin) * scaleY)
                                        + childTopY;
                        int parentLeft = parentRect.left;
                        childRect.left = paddingLeft;
                        childRect.top = childTopY;
                        childRect.right = parentWidth + parentLeft;
                        childRect.bottom = paddingTop;
                        paddingLeft = parentLeft;
                    } else if (verticalGravity == Gravity.BOTTOM) {
                        int childTopY = (int) (topMargin * scaleY);
                        paddingLeft = parentRect.left;
                        childRect.left = paddingLeft;
                        childRect.top = paddingTop;
                        childRect.right = parentWidth + paddingLeft;
                        childRect.bottom = paddingTop - childTopY;
                        paddingTop = (int) ((paddingTop + childHeight + bottomMargin) * scaleY);
                    } else {
                        int childBottomY =
                                (int) ((childHeight + topMargin + bottomMargin) * scaleY)
                                        + paddingTop;
                        paddingLeft = parentRect.left;
                        childRect.left = paddingLeft;
                        childRect.top = paddingTop;
                        childRect.right = parentWidth + paddingLeft;
                        childRect.bottom = childBottomY;
                        paddingTop = childBottomY;
                    }
                } else {
                    if (horizontalGravity == Gravity.CENTER_HORIZONTAL) {
                        if (i == 0) {
                            int childStartX = childLocationOnScreen[0] - (int) (leftMargin * scaleX);
                            int parentTop = parentRect.top;
                            addViewInfo(
                                    new Rect(
                                            paddingLeft,
                                            parentTop,
                                            childStartX,
                                            parentHeight + parentTop),
                                    linearLayout,
                                    0,
                                    calculateViewDepth(linearLayout) + 1);
                            paddingLeft = childStartX;
                        }
                        paddingTop = parentRect.top;
                        childRect.left = paddingLeft;
                        childRect.top = paddingTop;
                        childRect.right =
                                (int) ((childWidth + leftMargin + rightMargin) * scaleX)
                                        + paddingLeft;
                        childRect.bottom = parentHeight + paddingTop;
                        paddingLeft = childRect.right;
                    } else if (horizontalGravity == Gravity.RIGHT) {
                        paddingTop = parentRect.top;
                        childRect.left = paddingLeft;
                        childRect.top = paddingTop;
                        childRect.right = paddingLeft - (int) (leftMargin * scaleX);
                        childRect.bottom = parentHeight + paddingTop;
                        paddingLeft = (int) ((paddingLeft + childWidth + rightMargin) * scaleX);
                    } else {
                        paddingTop = parentRect.top;
                        childRect.left = paddingLeft;
                        childRect.top = paddingTop;
                        childRect.right =
                                (int) ((childWidth + leftMargin + rightMargin) * scaleX)
                                        + paddingLeft;
                        childRect.bottom = parentHeight + paddingTop;
                        paddingLeft = childRect.right;
                    }
                }
                addViewInfo(
                        childRect, linearLayout, childIndex, calculateViewDepth(linearLayout) + 1);

                if (child instanceof ItemLinearLayout) {
                    addDroppableForLinearLayout(view, (ItemLinearLayout) child);
                } else if (child instanceof ItemHorizontalScrollView) {
                    addDroppableForScrollableContainer(view, (ViewGroup) child);
                } else if (child instanceof ItemVerticalScrollView) {
                    addDroppableForScrollableContainer(view, (ViewGroup) child);
                } else if (child instanceof ItemCardView) {
                    addDroppableForScrollableContainer(view, (ViewGroup) child);
                } else if (child instanceof ItemRelativeLayout relativeLayout) {
                    addDroppableForViewGroup(view, relativeLayout);
                }
                childIndex++;
            }


        }
    }

    private void addDroppableForViewGroup(ViewBean viewBean, ViewGroup viewGroup) {
        int[] viewLocationOnScreen = new int[2];
        viewGroup.getLocationOnScreen(viewLocationOnScreen);
        int xCoordinate = viewLocationOnScreen[0];
        int yCoordinate = viewLocationOnScreen[1];
        addViewInfo(new Rect(xCoordinate, yCoordinate,
                        (int) (viewGroup.getWidth() * getScaleX()) + xCoordinate,
                        (int) (viewGroup.getHeight() * getScaleY()) + yCoordinate),
                viewGroup, -1, calculateViewDepth(viewGroup)
        );
        for (int i = 0; i < viewGroup.getChildCount(); i++) {
            View childAt = viewGroup.getChildAt(i);
            if (childAt != null && childAt.getTag() != null && (viewBean == null || viewBean.id == null || !childAt.getTag().equals(viewBean.id)) && childAt.getVisibility() == View.VISIBLE) {
                if (childAt instanceof ItemLinearLayout) {
                    addDroppableForLinearLayout(viewBean, (ItemLinearLayout) childAt);
                } else if (childAt instanceof ItemHorizontalScrollView) {
                    addDroppableForScrollableContainer(viewBean, (ViewGroup) childAt);
                } else if (childAt instanceof ItemVerticalScrollView) {
                    addDroppableForScrollableContainer(viewBean, (ViewGroup) childAt);
                } else if (childAt instanceof ItemCardView) {
                    addDroppableForScrollableContainer(viewBean, (ViewGroup) childAt);
                } else if (childAt instanceof ItemRelativeLayout relativeLayout) {
                    addDroppableForViewGroup(viewBean, relativeLayout);
                }
            }
        }
    }

    private void addDroppableForScrollableContainer(ViewBean viewBean, ViewGroup viewGroup) {
        int childCount = viewGroup.getChildCount();
        int index = 0;
        for (int i = 0; i < childCount; i++) {
            View childAt = viewGroup.getChildAt(i);
            if (childAt != null && childAt.getTag() != null && (viewBean == null || viewBean.id == null || !childAt.getTag().equals(viewBean.id)) && childAt.getVisibility() == View.VISIBLE) {
                index++;
                if (childAt instanceof ItemLinearLayout) {
                    addDroppableForLinearLayout(viewBean, (ItemLinearLayout) childAt);
                } else if (childAt instanceof ItemHorizontalScrollView) {
                    addDroppableForScrollableContainer(viewBean, (ViewGroup) childAt);
                } else if (childAt instanceof ItemVerticalScrollView) {
                    addDroppableForScrollableContainer(viewBean, (ViewGroup) childAt);
                } else if (childAt instanceof ItemCardView) {
                    addDroppableForScrollableContainer(viewBean, (ViewGroup) childAt);
                } else if (childAt instanceof ItemRelativeLayout relativeLayout) {
                    addDroppableForViewGroup(viewBean, relativeLayout);
                }
            }
        }
        if (index < 1) {
            int[] viewLocationOnScreen = new int[2];
            viewGroup.getLocationOnScreen(viewLocationOnScreen);
            int xCoordinate = viewLocationOnScreen[0];
            int yCoordinate = viewLocationOnScreen[1];
            addViewInfo(new Rect(xCoordinate, yCoordinate,
                            (int) (viewGroup.getWidth() * getScaleX()) + xCoordinate,
                            (int) (viewGroup.getHeight() * getScaleY()) + yCoordinate),
                    viewGroup, -1, calculateViewDepth(viewGroup)
            );
        }
    }

    private void addViewInfo(Rect rect, View view, int index, int depth) {
        viewInfos.add(new ViewInfo(rect, view, index, depth));
    }

    public void addViewAndUpdateIndex(View view) {
        ViewBean bean = ((ItemView) view).getBean();
        if (rootLayout != null) {
            ViewGroup viewGroup = rootLayout.findViewWithTag(bean.parent);
            viewGroup.addView(view, bean.index);
            if (bean.parentType == ViewBean.VIEW_TYPE_LAYOUT_RELATIVE) {
                updateRelativeParentViews(view, new InjectAttributeHandler(bean));
            }
            if (viewGroup instanceof ScrollContainer scrollContainer) {
                scrollContainer.reindexChildren();
            }
        }
    }

    private int getActualParentType(View view, int defaultValue) {
        var parent = (ViewGroup) view.getParent();
        if (parent != null) {
            if (parent instanceof ItemLinearLayout) {
                return ViewBean.VIEW_TYPE_LAYOUT_LINEAR;
            } else if (parent instanceof ItemRelativeLayout) {
                return ViewBean.VIEW_TYPE_LAYOUT_RELATIVE;
            } else if (parent instanceof ItemCardView) {
                return ViewBeans.VIEW_TYPE_LAYOUT_CARDVIEW;
            } else if (parent instanceof ItemHorizontalScrollView) {
                return ViewBean.VIEW_TYPE_LAYOUT_HSCROLLVIEW;
            } else if (parent instanceof ItemVerticalScrollView) {
                return ViewBean.VIEW_TYPE_LAYOUT_VSCROLLVIEW;
            }
        }
        return defaultValue;
    }

    private void applyElevation(View view, int elevationDp) {
        if (elevationDp > 0) {
            float elevationPx = ViewUtil.dpToPx(getContext(), elevationDp);
            view.setElevation(elevationPx);
            Drawable bg = view.getBackground();
            boolean useBoundsOutline = shouldUseBoundsOutline(view, bg);
            if (!useBoundsOutline && bg instanceof ColorDrawable colorDrawable) {
                GradientDrawable gd = new GradientDrawable();
                gd.setColor(colorDrawable.getColor());
                gd.setShape(GradientDrawable.RECTANGLE);
                view.setBackground(gd);
            }
            view.setOutlineProvider(useBoundsOutline
                    ? ViewOutlineProvider.BOUNDS
                    : ViewOutlineProvider.BACKGROUND);
            view.invalidateOutline();
            if (view.getParent() != null) {
                disableClipInAncestors(view);
            } else {
                view.addOnAttachStateChangeListener(new View.OnAttachStateChangeListener() {
                    @Override
                    public void onViewAttachedToWindow(View v) {
                        disableClipInAncestors(v);
                        v.removeOnAttachStateChangeListener(this);
                    }
                    @Override
                    public void onViewDetachedFromWindow(View v) {}
                });
            }
        } else if (view.getElevation() != 0) {
            view.setElevation(0);
            view.invalidateOutline();
        }
    }

    private int getInjectedElevationDp(InjectAttributeHandler handler) {
        String elevation = handler.getAttributeValueOf("elevation");
        return elevation.isEmpty() ? -1 : PropertiesUtil.resolveSize(elevation, 0);
    }

    private int resolvePreviewElevation(InjectAttributeHandler handler, int fallbackDp) {
        int injectedElevation = getInjectedElevationDp(handler);
        return injectedElevation >= 0 ? injectedElevation : fallbackDp;
    }

    private boolean shouldUseBoundsOutline(View view, Drawable background) {
        if (background == null) {
            return true;
        }
        if (background instanceof ColorDrawable colorDrawable) {
            return Color.alpha(colorDrawable.getColor()) == 0;
        }
        return background.getAlpha() == 0;
    }

    private void disableClipInAncestors(View view) {
        ViewGroup parent = view.getParent() instanceof ViewGroup ? (ViewGroup) view.getParent() : null;
        int maxHops = 16;
        while (parent != null && maxHops-- > 0) {
            parent.setClipChildren(false);
            parent.setClipToPadding(false);
            if (parent == this) {
                break;
            }
            parent = parent.getParent() instanceof ViewGroup ? (ViewGroup) parent.getParent() : null;
        }
    }

    private void updateLayout(View view, ViewBean viewBean) {
        if (crashlytics != null) crashlytics.log("ViewPane: Updating layout");
        LayoutBean layoutBean = viewBean.layout;
        int width = layoutBean.width;
        int height = layoutBean.height;
        if (width > 0) {
            width = (int) ViewUtil.dpToPx(getContext(), (float) viewBean.layout.width);
        }
        if (height > 0) {
            height = (int) ViewUtil.dpToPx(getContext(), (float) viewBean.layout.height);
        }

        int leftMargin = (int) ViewUtil.dpToPx(getContext(), (float) viewBean.layout.marginLeft);
        int topMargin = (int) ViewUtil.dpToPx(getContext(), (float) viewBean.layout.marginTop);
        int rightMargin = (int) ViewUtil.dpToPx(getContext(), (float) viewBean.layout.marginRight);
        int bottomMargin = (int) ViewUtil.dpToPx(getContext(), (float) viewBean.layout.marginBottom);

        if (viewBean.layout.backgroundResColor == null) {
            int bg = viewBean.layout.backgroundColor;
            // 0xffffff = LayoutBean default «unset» — LayoutGenerator omits android:background; do not apply
            // 0x00FFFFFF as setBackgroundColor would be fully transparent (alpha 0) and breaks preview.
            if (bg == 0xffffff) {
                if (view instanceof ItemButton || view instanceof ItemEditText || view instanceof ItemMaterialButton) {
                    view.setBackgroundColor(bg);
                } else {
                    view.setBackground(null);
                }
            } else if (bg == 0) {
                if (view instanceof ItemButton || view instanceof ItemEditText || view instanceof ItemMaterialButton) {
                    view.setBackgroundColor(bg);
                } else {
                    view.setBackground(null);
                }
            } else {
                view.setBackgroundColor(bg);
            }
        } else {
            view.setBackgroundColor(PropertiesUtil.parseColor(colorResourceResolver.getColorValue(context, viewBean.layout.backgroundResColor, 3, material3LibraryManager.canUseNightVariantColors())));
        }
        if (viewBean.parentType == ViewBean.VIEW_TYPE_LAYOUT_LINEAR) {
            LinearLayout.LayoutParams layoutParams2 = new LinearLayout.LayoutParams(width, height);
            layoutParams2.setMargins(leftMargin, topMargin, rightMargin, bottomMargin);
            LayoutBean layoutBean3 = viewBean.layout;
            view.setPadding(layoutBean3.paddingLeft, layoutBean3.paddingTop, layoutBean3.paddingRight, layoutBean3.paddingBottom);
            int layoutGravity = viewBean.layout.layoutGravity;
            if (layoutGravity != LayoutBean.GRAVITY_NONE) {
                layoutParams2.gravity = layoutGravity;
            }
            layoutParams2.weight = viewBean.layout.weight;
            view.setLayoutParams(layoutParams2);
        } else if (viewBean.parentType == ViewBean.VIEW_TYPE_LAYOUT_RELATIVE) {
            RelativeLayout.LayoutParams layoutParams2 = new RelativeLayout.LayoutParams(width, height);
            layoutParams2.setMargins(leftMargin, topMargin, rightMargin, bottomMargin);
            LayoutBean layoutBean3 = viewBean.layout;
            view.setPadding(layoutBean3.paddingLeft, layoutBean3.paddingTop, layoutBean3.paddingRight, layoutBean3.paddingBottom);
            view.setLayoutParams(layoutParams2);
        } else {
            FrameLayout.LayoutParams layoutParams3 = new FrameLayout.LayoutParams(width, height);
            layoutParams3.setMargins(leftMargin, topMargin, rightMargin, bottomMargin);
            LayoutBean layoutBean4 = viewBean.layout;
            view.setPadding(layoutBean4.paddingLeft, layoutBean4.paddingTop, layoutBean4.paddingRight, layoutBean4.paddingBottom);
            int layoutGravity = viewBean.layout.layoutGravity;
            if (layoutGravity != LayoutBean.GRAVITY_NONE) {
                layoutParams3.gravity = layoutGravity;
            }
            view.setLayoutParams(layoutParams3);
        }
    }

    private void updateRelativeParentViews(View view, InjectAttributeHandler handler) {
        var viewBean = handler.getBean();
        updateRelative(view, handler);

        ViewGroup parent = rootLayout.findViewWithTag(viewBean.parent);
        if (parent == null) {
            return;
        }

        for (int i = 0; i < parent.getChildCount(); i++) {
            var child = parent.getChildAt(i);
            if (child instanceof ItemView editorItem) {
                updateRelative(child, new InjectAttributeHandler(editorItem.getBean()));
            }
        }
    }

    private void updateRelative(View view, InjectAttributeHandler handler) {
        String layout_centerInParent = handler.getAttributeValueOf("layout_centerInParent");
        String layout_centerVertical = handler.getAttributeValueOf("layout_centerVertical");
        String layout_centerHorizontal = handler.getAttributeValueOf("layout_centerHorizontal");

        var bean = handler.getBean();
        var parent = bean.parentAttributes;
        if (Boolean.parseBoolean(layout_centerInParent)
                || parent.containsKey("android:layout_centerInParent")
                && Boolean.parseBoolean(parent.get("android:layout_centerInParent")))
            InvokeUtil.invoke(
                    view.getLayoutParams(),
                    "addRule",
                    new Class[]{int.class},
                    RelativeLayout.CENTER_IN_PARENT);

        if (Boolean.parseBoolean(layout_centerVertical)
                || parent.containsKey("android:layout_centerVertical")
                && Boolean.parseBoolean(parent.get("android:layout_centerVertical")))
            InvokeUtil.invoke(
                    view.getLayoutParams(),
                    "addRule",
                    new Class[]{int.class},
                    RelativeLayout.CENTER_VERTICAL);

        if (Boolean.parseBoolean(layout_centerHorizontal)
                || parent.containsKey("android:layout_centerHorizontal")
                && Boolean.parseBoolean(parent.get("android:layout_centerHorizontal")))
            InvokeUtil.invoke(
                    view.getLayoutParams(),
                    "addRule",
                    new Class[]{int.class},
                    RelativeLayout.CENTER_HORIZONTAL);

        String layout_alignParentStart = handler.getAttributeValueOf("layout_alignParentStart");
        String layout_alignParentRight = handler.getAttributeValueOf("layout_alignParentRight");
        String layout_alignParentTop = handler.getAttributeValueOf("layout_alignParentTop");
        String layout_alignParentEnd = handler.getAttributeValueOf("layout_alignParentEnd");
        String layout_alignParentLeft = handler.getAttributeValueOf("layout_alignParentLeft");
        String layout_alignParentBottom = handler.getAttributeValueOf("layout_alignParentBottom");

        if (Boolean.parseBoolean(layout_alignParentStart)
                || parent.containsKey("android:layout_alignParentStart")
                && Boolean.parseBoolean(parent.get("android:layout_alignParentStart"))) {
            InvokeUtil.invoke(
                    view.getLayoutParams(),
                    "addRule",
                    new Class[]{int.class},
                    RelativeLayout.ALIGN_PARENT_START);
        }

        if (Boolean.parseBoolean(layout_alignParentRight)
                || parent.containsKey("android:layout_alignParentRight")
                && Boolean.parseBoolean(parent.get("android:layout_alignParentRight"))) {
            InvokeUtil.invoke(
                    view.getLayoutParams(),
                    "addRule",
                    new Class[]{int.class},
                    RelativeLayout.ALIGN_PARENT_RIGHT);
        }

        if (Boolean.parseBoolean(layout_alignParentTop)
                || parent.containsKey("android:layout_alignParentTop")
                && Boolean.parseBoolean(parent.get("android:layout_alignParentTop"))) {
            InvokeUtil.invoke(
                    view.getLayoutParams(),
                    "addRule",
                    new Class[]{int.class},
                    RelativeLayout.ALIGN_PARENT_TOP);
        }

        if (Boolean.parseBoolean(layout_alignParentEnd)
                || parent.containsKey("android:layout_alignParentEnd")
                && Boolean.parseBoolean(parent.get("android:layout_alignParentEnd"))) {
            InvokeUtil.invoke(
                    view.getLayoutParams(),
                    "addRule",
                    new Class[]{int.class},
                    RelativeLayout.ALIGN_PARENT_END);
        }

        if (Boolean.parseBoolean(layout_alignParentLeft)
                || parent.containsKey("android:layout_alignParentLeft")
                && Boolean.parseBoolean(parent.get("android:layout_alignParentLeft"))) {
            InvokeUtil.invoke(
                    view.getLayoutParams(),
                    "addRule",
                    new Class[]{int.class},
                    RelativeLayout.ALIGN_PARENT_LEFT);
        }

        if (Boolean.parseBoolean(layout_alignParentBottom)
                || parent.containsKey("android:layout_alignParentBottom")
                && Boolean.parseBoolean(parent.get("android:layout_alignParentBottom"))) {
            InvokeUtil.invoke(
                    view.getLayoutParams(),
                    "addRule",
                    new Class[]{int.class},
                    RelativeLayout.ALIGN_PARENT_BOTTOM);
        }

        if (parent.containsKey("android:layout_alignStart")) {
            setRelativeRule(view, parent.get("android:layout_alignStart"), RelativeLayout.ALIGN_START);
        } else setRelativeRule(view, handler, "layout_alignStart", RelativeLayout.ALIGN_START);
        if (parent.containsKey("android:layout_alignRight")) {
            setRelativeRule(view, parent.get("android:layout_alignRight"), RelativeLayout.ALIGN_RIGHT);
        } else setRelativeRule(view, handler, "layout_alignRight", RelativeLayout.ALIGN_RIGHT);
        if (parent.containsKey("android:layout_alignTop")) {
            setRelativeRule(view, parent.get("android:layout_alignTop"), RelativeLayout.ALIGN_TOP);
        } else setRelativeRule(view, handler, "layout_alignTop", RelativeLayout.ALIGN_TOP);
        if (parent.containsKey("android:layout_alignEnd")) {
            setRelativeRule(view, parent.get("android:layout_alignEnd"), RelativeLayout.ALIGN_END);
        } else setRelativeRule(view, handler, "layout_alignEnd", RelativeLayout.ALIGN_END);
        if (parent.containsKey("android:layout_alignLeft")) {
            setRelativeRule(view, parent.get("android:layout_alignLeft"), RelativeLayout.ALIGN_LEFT);
        } else setRelativeRule(view, handler, "layout_alignLeft", RelativeLayout.ALIGN_LEFT);
        if (parent.containsKey("android:layout_alignBottom")) {
            setRelativeRule(view, parent.get("android:layout_alignBottom"), RelativeLayout.ALIGN_BOTTOM);
        } else setRelativeRule(view, handler, "layout_alignBottom", RelativeLayout.ALIGN_BOTTOM);
        if (parent.containsKey("android:layout_alignBaseline")) {
            setRelativeRule(view, parent.get("android:layout_alignBaseline"), RelativeLayout.ALIGN_BASELINE);
        } else
            setRelativeRule(view, handler, "layout_alignBaseline", RelativeLayout.ALIGN_BASELINE);

        if (parent.containsKey("android:layout_above")) {
            setRelativeRule(view, parent.get("android:layout_above"), RelativeLayout.ABOVE);
        } else setRelativeRule(view, handler, "layout_above", RelativeLayout.ABOVE);
        if (parent.containsKey("android:layout_below")) {
            setRelativeRule(view, parent.get("android:layout_below"), RelativeLayout.BELOW);
        } else setRelativeRule(view, handler, "layout_below", RelativeLayout.BELOW);
        if (parent.containsKey("android:layout_toStartOf")) {
            setRelativeRule(view, parent.get("android:layout_toStartOf"), RelativeLayout.START_OF);
        } else setRelativeRule(view, handler, "layout_toStartOf", RelativeLayout.START_OF);
        if (parent.containsKey("android:layout_toRightOf")) {
            setRelativeRule(view, parent.get("android:layout_toRightOf"), RelativeLayout.RIGHT_OF);
        } else setRelativeRule(view, handler, "layout_toRightOf", RelativeLayout.RIGHT_OF);
        if (parent.containsKey("android:layout_toEndOf")) {
            setRelativeRule(view, parent.get("android:layout_toEndOf"), RelativeLayout.END_OF);
        } else setRelativeRule(view, handler, "layout_toEndOf", RelativeLayout.END_OF);
        if (parent.containsKey("android:layout_toLeftOf")) {
            setRelativeRule(view, parent.get("android:layout_toLeftOf"), RelativeLayout.LEFT_OF);
        } else setRelativeRule(view, handler, "layout_toLeftOf", RelativeLayout.LEFT_OF);
    }

    private void setRelativeRule(
            View view, InjectAttributeHandler handler, String attribute, int rule) {
        String referenceId = handler.getAttributeValueOf(attribute);
        if (referenceId != null && !referenceId.isEmpty()) {
            var reference = PropertiesUtil.getUnitOrPrefix(referenceId);
            if (reference != null) {
                setRelativeRule(view, reference.second, rule);
            }
        }
    }

    private void setRelativeRule(View view, String id, int rule) {
        View refView = rootLayout.findViewWithTag(id);
        if (refView != null) {
            InvokeUtil.invoke(
                    view.getLayoutParams(),
                    "addRule",
                    new Class[]{int.class, int.class},
                    rule,
                    refView.getId());
        }
    }

    private String getImportedFontPath(String fontName) {
        if (importedFontPathCache == null) {
            importedFontPathCache = loadImportedFontPaths();
        }
        return importedFontPathCache.getOrDefault(fontName, "");
    }

    private HashMap<String, String> loadImportedFontPaths() {
        HashMap<String, String> fontPaths = new HashMap<>();
        File fontDirectory = new File(SketchwarePaths.getProjectResourcePath(sc_id), "font");
        File[] fontFiles = fontDirectory.listFiles();
        if (fontFiles == null) {
            return fontPaths;
        }
        for (File fontFile : fontFiles) {
            if (fontFile.isFile()) {
                fontPaths.put(FileUtil.getFileNameNoExtension(fontFile.getName()), fontFile.getAbsolutePath());
            }
        }
        return fontPaths;
    }

    private void updateTextView(TextView textView, ViewBean viewBean) {
        String textContent = viewBean.text.text;
        if (textContent != null && textContent.contains("\\n")) {
            textContent = viewBean.text.text.replace("\\n", "\n");
        }
        textView.setText(textContent.startsWith(stringsStart) ? getXmlString(textContent) : textContent);
        String textFont = new InjectAttributeHandler(viewBean).getAttributeValueOf("fontFamily");
        if (textFont != null && !textFont.isEmpty()) {
            if (textFont.startsWith("@font/")) {
                textFont = textFont.substring(6);
                String textFontPath = getImportedFontPath(textFont);
                textView.setTypeface(
                        textFontPath != null
                                && !textFontPath.isEmpty()
                                && new File(textFontPath).exists()
                                ? Typeface.createFromFile(textFontPath)
                                : null,
                        viewBean.text.textType);
            } else {
                textView.setTypeface(null, viewBean.text.textType);
            }
        } else {
            textView.setTypeface(null, viewBean.text.textType);
        }
        if (defaultTextColor == 0) {
            defaultTextColor = textView.getTextColors().getDefaultColor();
        }
        if (viewBean.text.resTextColor == null) {
            textView.setTextColor(
                    viewBean.text.textColor == 0xffffff ? defaultTextColor : viewBean.text.textColor
            );
        } else {
            textView.setTextColor(PropertiesUtil.parseColor(colorResourceResolver.getColorValue(context, viewBean.text.resTextColor, 3, material3LibraryManager.canUseNightVariantColors())));
        }
        textView.setTextSize(viewBean.text.textSize);
        textView.setLines(viewBean.text.line);
        textView.setSingleLine(viewBean.text.singleLine != 0);
    }

    public String getXmlString(String key) {
        if (sc_id == null) {
            return key;
        }
        if (xmlStringCache == null || !sc_id.equals(xmlStringCacheScId)) {
            xmlStringCache = new HashMap<>();
            xmlStringCacheScId = sc_id;
            String filePath = SketchwarePaths.getProjectResourceValuesFilePath(sc_id, "strings.xml");
            ArrayList<HashMap<String, Object>> stringsListMap = new ArrayList<>();
            StringResourceResolver stringResourceResolver = new StringResourceResolver();
            stringResourceResolver.convertXmlStringsToListMap(FileUtil.readFileIfExist(filePath), stringsListMap);
            for (HashMap<String, Object> map : stringsListMap) {
                Object keyObj = map.get("key");
                Object textObj = map.get("text");
                if (keyObj != null && textObj != null) {
                    String k = stringsStart + keyObj.toString().trim();
                    xmlStringCache.put(k, textObj.toString());
                }
            }
        }
        if (key.equals("@string/app_name") && !xmlStringCache.containsKey(key)) {
            return MapValueHelper.getString(ProjectListManager.getProjectById(sc_id), "my_app_name");
        }
        String value = xmlStringCache.get(key);
        return value != null ? value : key;
    }

    public void invalidateXmlStringCache() {
        xmlStringCache = null;
    }

    private void updateEditText(EditText editText, ViewBean viewBean) {
        String hintText = viewBean.text.hint;
        editText.setHint(hintText.startsWith(stringsStart) ? getXmlString(hintText) : hintText);
        if (defaultHintColor == 0) {
            defaultHintColor = editText.getHintTextColors().getDefaultColor();
        }
        if (viewBean.text.resHintColor == null) {
            editText.setHintTextColor(
                    viewBean.text.hintColor == 0xffffff ? defaultHintColor : viewBean.text.hintColor
            );
        } else {
            editText.setHintTextColor(PropertiesUtil.parseColor(colorResourceResolver.getColorValue(context, viewBean.text.resHintColor, 3, material3LibraryManager.canUseNightVariantColors())));
        }
    }

    private void updateCardView(ItemCardView cardView, InjectAttributeHandler handler) {
        var bean = handler.getBean();
        String cardBackgroundColor = handler.getAttributeValueOf("cardBackgroundColor");
        String cardElevation = handler.getAttributeValueOf("cardElevation");
        String cardCornerRadius = handler.getAttributeValueOf("cardCornerRadius");
        String compatPadding = handler.getAttributeValueOf("cardUseCompatPadding");
        String strokeColor = handler.getAttributeValueOf("strokeColor");
        String strokeWidth = handler.getAttributeValueOf("strokeWidth");

        if (cardBackgroundColor.isEmpty()) {
            if (bean.layout.backgroundResColor == null) {
                cardView.setCardBackgroundColor(bean.layout.backgroundColor);
            } else {
                cardView.setCardBackgroundColor(PropertiesUtil.parseColor(colorResourceResolver.getColorValue(context, bean.layout.backgroundResColor, 3, material3LibraryManager.canUseNightVariantColors())));
            }
        } else {
            cardView.setCardBackgroundColor(PropertiesUtil.parseColor(colorResourceResolver.getColorValue(context, cardBackgroundColor, 3, material3LibraryManager.canUseNightVariantColors())));
        }

        int fallbackElevation = bean.layout.elevation > 0 ? bean.layout.elevation : 4;
        cardView.setCardElevation(PropertiesUtil.resolveSize(cardElevation, fallbackElevation));
        cardView.setRadius(PropertiesUtil.resolveSize(cardCornerRadius, 8));
        cardView.setUseCompatPadding(Boolean.parseBoolean(TextUtils.isEmpty(compatPadding) ? "false" : compatPadding));
        cardView.setStrokeWidth(PropertiesUtil.resolveSize(strokeWidth, 0));
        cardView.setStrokeColor(PropertiesUtil.isHexColor(strokeColor) ? PropertiesUtil.parseColor(strokeColor) : Color.WHITE);
    }

    private void updateCircleImageView(ItemCircleImageView imageView, InjectAttributeHandler handler) {
        String borderColor = handler.getAttributeValueOf("civ_border_color");
        String backgroundColor = handler.getAttributeValueOf("civ_circle_background_color");
        String borderWidth = handler.getAttributeValueOf("civ_border_width");
        String borderOverlay = handler.getAttributeValueOf("civ_border_overlay");

        imageView.setBorderColor(PropertiesUtil.isHexColor(borderColor) ? PropertiesUtil.parseColor(borderColor) : ContextCompat.getColor(getContext(), R.color.editor_default_border));
        imageView.setCircleBackgroundColor(PropertiesUtil.isHexColor(backgroundColor) ? PropertiesUtil.parseColor(backgroundColor) : ContextCompat.getColor(getContext(), R.color.editor_default_border));
        imageView.setBorderWidth(PropertiesUtil.resolveSize(borderWidth, 3));
        imageView.setBorderOverlay(Boolean.parseBoolean(TextUtils.isEmpty(borderOverlay) ? "false" : borderOverlay));
    }

    private void updateTabLayout(ItemTabLayout tabLayout, InjectAttributeHandler handler) {
        String gravity = handler.getAttributeValueOf("tabGravity");
        String mode = handler.getAttributeValueOf("tabMode");
        String indicatorHeight = handler.getAttributeValueOf("tabIndicatorHeight");
        String indicatorColor = handler.getAttributeValueOf("tabIndicatorColor");
        String textColor = handler.getAttributeValueOf("tabTextColor");
        String selectedTextColor = handler.getAttributeValueOf("tabSelectedTextColor");

        tabLayout.setTabGravity(switch (gravity) {
            case "center" -> TabLayout.GRAVITY_CENTER;
            case "start" -> TabLayout.GRAVITY_START;
            default -> TabLayout.GRAVITY_FILL;
        });
        tabLayout.setTabMode(switch (mode) {
            case "auto" -> TabLayout.MODE_AUTO;
            case "scrollable" -> TabLayout.MODE_SCROLLABLE;
            default -> TabLayout.MODE_FIXED;
        });
        tabLayout.setSelectedTabIndicatorHeight(PropertiesUtil.resolveSize(indicatorHeight, 3));
        tabLayout.setSelectedTabIndicatorColor(PropertiesUtil.isHexColor(indicatorColor) ? PropertiesUtil.parseColor(indicatorColor) : ContextCompat.getColor(getContext(), R.color.editor_tab_indicator));
        int tabTextColor = PropertiesUtil.isHexColor(textColor) ? PropertiesUtil.parseColor(textColor) : ContextCompat.getColor(getContext(), R.color.editor_tab_text);
        int tabSelectedTextColor = PropertiesUtil.isHexColor(selectedTextColor) ? PropertiesUtil.parseColor(selectedTextColor) : Color.WHITE;
        tabLayout.setTabTextColors(tabTextColor, tabSelectedTextColor);
    }

    private void updateMaterialButton(ItemMaterialButton materialButton, InjectAttributeHandler handler) {
        String backgroundTint = handler.getAttributeValueOf("backgroundTint");
        String radius = handler.getAttributeValueOf("cornerRadius");
        String stroke = handler.getAttributeValueOf("strokeWidth");
        if (!backgroundTint.isEmpty()) {
            Integer tintColor = colorResourceResolver.resolveColorInt(context, backgroundTint, 3, material3LibraryManager.canUseNightVariantColors());
            if (tintColor != null) {
                materialButton.setBackgroundTintList(ColorStateList.valueOf(tintColor));
            }
        }
        materialButton.setStrokeWidth(PropertiesUtil.resolveSize(stroke, 0));
        materialButton.setCornerRadius(PropertiesUtil.resolveSize(radius, 8));
    }

    private String extractAttrValue(String line, String attribute) {
        Matcher matcher = Pattern.compile("=\"([^\"]*)\"").matcher(line);
        return matcher.find() ? matcher.group(1) : "";
    }

    @NonNull
    @Override
    public String toString() {
        return getClass().getName() + "@" + Integer.toHexString(hashCode());
    }

    private record ViewInfo(Rect rect, View view, int index, int depth) {
    }

    private static FirebaseCrashlytics getFirebaseCrashlytics() {
        try {
            return FirebaseCrashlytics.getInstance();
        } catch (IllegalStateException e) {
            return null;
        }
    }
}
