package pro.sketchware.activities.editor.view;


import android.util.Log;
import android.animation.ObjectAnimator;
import android.content.Context;
import android.graphics.PorterDuff;
import android.text.InputType;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.DecelerateInterpolator;
import android.view.inputmethod.EditorInfo;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;

import pro.sketchware.beans.ProjectFileBean;
import pro.sketchware.beans.ViewBean;
import pro.sketchware.widgets.ViewIdSpinnerItem;
import pro.sketchware.activities.editor.property.ViewPropertyItems;
import pro.sketchware.widgets.CustomHorizontalScrollView;
import com.google.android.material.card.MaterialCardView;
import com.google.android.material.color.MaterialColors;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;

import java.util.ArrayList;

import pro.sketchware.core.callback.ViewEditorCallback;
import pro.sketchware.core.callback.FileSelectedCallback;
import pro.sketchware.core.callback.PropertyChangedCallback;
import pro.sketchware.core.callback.ViewBeanCallback;
import pro.sketchware.core.validation.UniqueNameValidator;
import pro.sketchware.core.project.ImageCollectionManager;
import pro.sketchware.core.callback.EventSelectedCallback;
import pro.sketchware.core.project.WidgetCollectionManager;
import pro.sketchware.util.SketchToast;
import pro.sketchware.core.project.ProjectDataManager;
import pro.sketchware.util.UIHelper;
import pro.sketchware.util.ViewUtil;
import pro.sketchware.core.project.ProjectSettings;
import pro.sketchware.util.Helper;
import pro.sketchware.R;

public class ViewProperty extends LinearLayout implements PropertyChangedCallback {

    private Context context;
    private final ArrayList<ViewBean> projectActivityViews = new ArrayList<>();
    private String sc_id;
    private ProjectFileBean projectFile;
    private Spinner spnWidget;
    private ViewIdsAdapter idsAdapter;
    private FileSelectedCallback propertyTargetChangeListener = null;
    private LinearLayout layoutPropertySeeAll;
    private ViewPropertyItems viewPropertyItems;
    private SeeAllPropertiesFloatingItem seeAll;
    private View propertyLayout;
    private ViewEvents viewEvent;
    private ViewEditorCallback propertyListener = null;
    private ViewBeanCallback propertyValueChangedListener;
    private onPropertyDeleted onPropertyDeletedListener;
    private LinearLayout layoutPropertyGroup;
    private int selectedGroupId;
    private ImageView imgSave;
    private ImageView imgDelete;
    private ObjectAnimator showAllShower;
    private ObjectAnimator showAllHider;
    private boolean showAllVisible = true;
    private Runnable pendingPropertyContentRefresh;

    public ViewProperty(Context context) {
        super(context);
        initialize(context);
    }

    public ViewProperty(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        initialize(context);
    }

    @Override
    public void onPropertyChanged(String key, Object value) {
    }

    public interface onPropertyDeleted {
        void deleteProperty(ViewBean viewBean);
    }

    public void setOnPropertyDeleted(onPropertyDeleted onPropertyDeleted) {
        onPropertyDeletedListener = onPropertyDeleted;
    }

    public void setOnEventClickListener(EventSelectedCallback onEventClickListener) {
        viewEvent.setOnEventClickListener(onEventClickListener);
    }

    public void setOnPropertyListener(ViewEditorCallback onPropertyListener) {
        propertyListener = onPropertyListener;
    }

    public void setOnPropertyTargetChangeListener(FileSelectedCallback onPropertyTargetChangeListener) {
        propertyTargetChangeListener = onPropertyTargetChangeListener;
    }

    public void setOnPropertyValueChangedListener(ViewBeanCallback onPropertyValueChangedListener) {
        propertyValueChangedListener = onPropertyValueChangedListener;
        viewPropertyItems.setOnPropertyValueChangedListener(viewBean -> {
            if (propertyValueChangedListener != null) {
                propertyValueChangedListener.onViewBeanChanged(viewBean);
            }
        });
    }

    private void cancelSeeAllAnimations() {
        if (showAllShower.isRunning()) {
            showAllShower.cancel();
        }
        if (showAllHider.isRunning()) {
            showAllHider.cancel();
        }
    }

    private void initializeSeeAllAnimations() {
        if (showAllShower == null) {
            showAllShower = ObjectAnimator.ofFloat(layoutPropertySeeAll, View.TRANSLATION_Y, 0.0f);
            showAllShower.setDuration(400L);
            showAllShower.setInterpolator(new DecelerateInterpolator());
        }
        if (showAllHider == null) {
            showAllHider = ObjectAnimator.ofFloat(layoutPropertySeeAll, View.TRANSLATION_Y, ViewUtil.dpToPx(getContext(), 100.0f));
            showAllHider.setDuration(200L);
            showAllHider.setInterpolator(new DecelerateInterpolator());
        }
    }

    public void saveProperties() {
        if (viewPropertyItems != null) {
            viewPropertyItems.save();
        }
    }

    public void refreshPropertyGroups() {
        for (int i = 0; i < layoutPropertyGroup.getChildCount(); i++) {
            GroupItem item = (GroupItem) layoutPropertyGroup.getChildAt(i);

            if (selectedGroupId == (Integer) item.getTag()) {
                item.setSelected(true);
                item.animate().scaleX(0.9f).scaleY(0.9f).start();
            } else {
                item.setSelected(false);
                item.animate().scaleX(0.8f).scaleY(0.8f).start();
            }
        }

        ViewBean viewBean = getSelectedView();
        if (viewBean == null) {
            return;
        }

        if (selectedGroupId == 0) {
            propertyLayout.setVisibility(VISIBLE);
            layoutPropertySeeAll.setVisibility(VISIBLE);
            viewEvent.setVisibility(GONE);
        } else if (selectedGroupId == 1) {
            propertyLayout.setVisibility(VISIBLE);
            layoutPropertySeeAll.setVisibility(GONE);
            viewEvent.setVisibility(GONE);
        } else if (selectedGroupId == 2) {
            propertyLayout.setVisibility(GONE);
            layoutPropertySeeAll.setVisibility(GONE);
            viewEvent.setVisibility(VISIBLE);
        }

        schedulePropertyContentRefresh(selectedGroupId, viewBean.id);
    }

    private ViewBean getSelectedView() {
        int selectedPosition = idsAdapter.getSelectedItemPosition();
        if (selectedPosition < 0 || selectedPosition >= projectActivityViews.size()) {
            return null;
        }
        return projectActivityViews.get(selectedPosition);
    }

    private void schedulePropertyContentRefresh(int groupId, String viewId) {
        if (pendingPropertyContentRefresh != null) {
            removeCallbacks(pendingPropertyContentRefresh);
        }

        pendingPropertyContentRefresh = () -> {
            pendingPropertyContentRefresh = null;
            ViewBean selectedView = getSelectedView();
            if (selectedView == null || selectedGroupId != groupId || !isSameViewId(selectedView.id, viewId)) {
                return;
            }
            renderPropertyContent(groupId, selectedView);
        };
        post(pendingPropertyContentRefresh);
    }

    private boolean isSameViewId(String firstId, String secondId) {
        return firstId == null ? secondId == null : firstId.equals(secondId);
    }

    private void renderPropertyContent(int groupId, ViewBean viewBean) {
        if (groupId == 0) {
            viewPropertyItems.setProjectFileBean(projectFile);
            viewPropertyItems.initializeProperties(sc_id, viewBean);
            updateSeeAllView(viewBean);
        } else if (groupId == 1) {
            viewPropertyItems.setupRecentProperties(viewBean);
        } else if (groupId == 2) {
            viewEvent.setData(sc_id, projectFile, viewBean);
        }
    }

    @Override
    protected void onDetachedFromWindow() {
        if (pendingPropertyContentRefresh != null) {
            removeCallbacks(pendingPropertyContentRefresh);
            pendingPropertyContentRefresh = null;
        }
        super.onDetachedFromWindow();
    }

    private void showSaveToCollectionDialog() {
        MaterialAlertDialogBuilder dialog = new MaterialAlertDialogBuilder(getContext());
        dialog.setTitle(Helper.getResString(R.string.view_widget_favorites_save_title));
        dialog.setIcon(R.drawable.ic_bookmark_red_48dp);
        View view = ViewUtil.inflateLayout(getContext(), R.layout.property_popup_save_to_favorite);
        ((TextView) view.findViewById(R.id.tv_favorites_guide)).setText(Helper.getResString(R.string.view_widget_favorites_save_guide_new));
        EditText editText = view.findViewById(R.id.ed_input);
        editText.setPrivateImeOptions("defaultInputmode=english;");
        editText.setLines(1);
        editText.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        editText.setImeOptions(EditorInfo.IME_ACTION_DONE);

        UniqueNameValidator validator = new UniqueNameValidator(getContext(), view.findViewById(R.id.ti_input), WidgetCollectionManager.getInstance().getWidgetNames());
        dialog.setView(view);
        dialog.setPositiveButton(Helper.getResString(R.string.common_word_save), (v, which) -> {
            if (!UIHelper.isClickThrottled() && validator.isValid()) {
                String widgetName = Helper.getText(editText);
                ArrayList<ViewBean> viewBeans = ProjectDataManager.getProjectDataManager(sc_id).getViewWithChildren(projectFile.getXmlName(), projectActivityViews.get(idsAdapter.getSelectedItemPosition()));
                for (ViewBean viewBean : viewBeans) {
                    String backgroundResource = viewBean.layout.backgroundResource;
                    String resName = viewBean.image.resName;
                    if (backgroundResource != null && !backgroundResource.equals("NONE") && ProjectDataManager.getResourceManager(sc_id).hasImage(backgroundResource) && !ImageCollectionManager.getInstance().hasResource(backgroundResource)) {
                        try {
                            ImageCollectionManager.getInstance().addResource(sc_id, ProjectDataManager.getResourceManager(sc_id).getImageBean(backgroundResource));
                        } catch (Exception e) {
                            Log.e("ViewProperty", e.getMessage(), e);
                            SketchToast.warning(getContext(), e.getMessage(), SketchToast.TOAST_NORMAL).show();
                        }
                    }
                    if (resName != null && !resName.equals("default_image") && !resName.equals("NONE") && ProjectDataManager.getResourceManager(sc_id).hasImage(resName) && !ImageCollectionManager.getInstance().hasResource(resName)) {
                        try {
                            ImageCollectionManager.getInstance().addResource(sc_id, ProjectDataManager.getResourceManager(sc_id).getImageBean(resName));
                        } catch (Exception e) {
                            SketchToast.warning(getContext(), e.getMessage(), SketchToast.TOAST_NORMAL).show();
                        }
                    }
                }
                try { WidgetCollectionManager.getInstance().addWidget(widgetName, viewBeans, true); } catch (pro.sketchware.core.exception.CompileException ignored) {}
                if (propertyListener != null) {
                    propertyListener.onFavoritesChanged();
                }
                SketchToast.toast(getContext(), Helper.getResString(R.string.common_message_complete_save), SketchToast.TOAST_NORMAL).show();
                v.dismiss();
            }
        });
        dialog.setNegativeButton(Helper.getResString(R.string.common_word_cancel), null);
        dialog.show();
    }

    private void showDeleteViewBeanWidget() {
        new MaterialAlertDialogBuilder(context)
                .setTitle(Helper.getResString(R.string.view_widget_delete_title))
                .setMessage(Helper.getResString(R.string.view_widget_delete_description))
                .setPositiveButton(Helper.getResString(R.string.common_word_delete), (d, w) -> {
                    if (onPropertyDeletedListener != null) {
                        onPropertyDeletedListener.deleteProperty(projectActivityViews.get(idsAdapter.getSelectedItemPosition()));
                    }
                })
                .setNegativeButton(Helper.getResString(R.string.common_word_cancel), (d, w) -> d.dismiss())
                .show();
    }

    private void initialize(Context context) {
        this.context = context;
        ViewUtil.inflateLayoutInto(context, this, R.layout.view_property);
        layoutPropertyGroup = findViewById(R.id.layout_property_group);
        CustomHorizontalScrollView hcvProperty = findViewById(R.id.hcv_property);
        propertyLayout = findViewById(R.id.property_layout);
        LinearLayout propertyContents = findViewById(R.id.property_contents);
        layoutPropertySeeAll = findViewById(R.id.layout_property_see_all);
        viewEvent = findViewById(R.id.view_event);
        hcvProperty.setHorizontalScrollBarEnabled(false);
        hcvProperty.setOnScrollChangedListener((scrollX, scrollY, oldScrollX, oldScrollY) -> {
            if (Math.abs(scrollX - oldScrollY) <= 5) {
                return;
            }
            int maxScrollX = hcvProperty.getChildAt(0).getWidth() - hcvProperty.getWidth();
            if (scrollX > 100 && scrollX < maxScrollX) {
                if (scrollX > oldScrollX) {
                    if (showAllVisible) {
                        showAllVisible = false;
                        cancelSeeAllAnimations();
                        showAllHider.start();
                    }
                } else {
                    if (!showAllVisible) {
                        showAllVisible = true;
                        cancelSeeAllAnimations();
                        showAllShower.start();
                    }
                }
            } else if (scrollX >= maxScrollX) {
                if (showAllVisible) {
                    showAllVisible = false;
                    cancelSeeAllAnimations();
                    showAllHider.start();
                }
            } else {
                if (!showAllVisible) {
                    showAllVisible = true;
                    cancelSeeAllAnimations();
                    showAllShower.start();
                }
            }
        });
        imgSave = findViewById(R.id.img_save);
        imgSave.setOnClickListener(v -> {
            if (!UIHelper.isClickThrottled()) {
                showSaveToCollectionDialog();
            }
        });
        imgDelete = findViewById(R.id.img_delete);
        imgDelete.setOnClickListener(view -> showDeleteViewBeanWidget());
        spnWidget = findViewById(R.id.spn_widget);
        idsAdapter = new ViewIdsAdapter(context, projectActivityViews);
        spnWidget.setAdapter(idsAdapter);
        spnWidget.setSelection(0);
        spnWidget.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                idsAdapter.setPosition(position);
                selectView(projectActivityViews.get(position));
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });
        initializeGroups();
        initializeSeeAllAnimations();
        viewPropertyItems = new ViewPropertyItems(getContext());
        viewPropertyItems.setOrientation(HORIZONTAL);
        propertyContents.addView(viewPropertyItems);
    }

    private void selectView(ViewBean viewBean) {
        if (propertyTargetChangeListener != null) {
            propertyTargetChangeListener.onFileSelected(viewBean.id);
        }
        if ("_fab".equals(viewBean.id)) {
            imgSave.setVisibility(GONE);
            imgDelete.setVisibility(GONE);
        } else {
            imgSave.setVisibility(VISIBLE);
            imgDelete.setVisibility(VISIBLE);
        }
        viewPropertyItems.setProjectFileBean(projectFile);
        refreshPropertyGroups();
    }

    public void initialize(String sc_id, ProjectFileBean projectFileBean) {
        this.sc_id = sc_id;
        projectFile = projectFileBean;
        viewPropertyItems.setProjectId(sc_id);
        viewPropertyItems.setProjectSettings(new ProjectSettings(sc_id));
    }

    public boolean selectWidgetById(String widgetId) {
        for (int i = 0; i < projectActivityViews.size(); i++) {
            if (isSameViewId(projectActivityViews.get(i).id, widgetId)) {
                if (idsAdapter.getSelectedItemPosition() == i) {
                    selectView(projectActivityViews.get(i));
                } else {
                    spnWidget.setSelection(i);
                }
                return true;
            }
        }
        return false;
    }

    public void addActivityViews(ArrayList<ViewBean> activityViews, ViewBean fab) {
        projectActivityViews.clear();
        projectActivityViews.addAll(activityViews);
        if (fab != null) {
            projectActivityViews.add(0, fab);
        }
        idsAdapter.notifyDataSetChanged();
    }

    public void warmUpPropertyContent() {
        ViewBean warmUpView = getWarmUpView();
        if (warmUpView == null || sc_id == null || projectFile == null) {
            return;
        }
        viewPropertyItems.setProjectFileBean(projectFile);
        viewPropertyItems.initializeProperties(sc_id, warmUpView);
    }

    private ViewBean getWarmUpView() {
        for (ViewBean viewBean : projectActivityViews) {
            if (!"_fab".equals(viewBean.id)) {
                return viewBean;
            }
        }
        return projectActivityViews.isEmpty() ? null : projectActivityViews.get(0);
    }

    private void initializeGroups() {
        addGroup(0, R.string.property_group_basic);
        addGroup(1, R.string.property_group_recent);
        addGroup(2, R.string.property_group_event);
    }

    private void addGroup(int id, int labelResId) {
        GroupItem group = new GroupItem(getContext());
        group.configure(id, labelResId);
        group.setTag(id);
        layoutPropertyGroup.addView(group);
    }

    private void updateSeeAllView(ViewBean viewBean) {
        if (seeAll == null) {
            seeAll = new SeeAllPropertiesFloatingItem(getContext());
            seeAll.configure(R.drawable.color_more_96, R.string.common_word_see_all);
            seeAll.setView(viewBean);
            layoutPropertySeeAll.addView(seeAll);
            return;
        }
        seeAll.setView(viewBean);
    }

    private static class ViewIdsAdapter extends BaseAdapter {

        private final Context context;
        private final ArrayList<ViewBean> views;
        private int selectedItemPosition;

        public ViewIdsAdapter(Context context, ArrayList<ViewBean> viewBeans) {
            this.context = context;
            views = viewBeans;
        }

        private void setPosition(int position) {
            selectedItemPosition = position;
        }

        @Override
        public int getCount() {
            if (views == null) {
                return 0;
            } else {
                return views.size();
            }
        }

        @Override
        public View getDropDownView(int position, View convertView, ViewGroup parent) {
            return getSpinnerItem(position, convertView, selectedItemPosition == position, true);
        }

        @Override
        public ViewBean getItem(int position) {
            return views.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            return getSpinnerItem(position, convertView, false, false);
        }

        private int getSelectedItemPosition() {
            return selectedItemPosition;
        }

        private ViewIdSpinnerItem getSpinnerItem(int position, View convertView, boolean isSelected, boolean isDropDownView) {
            ViewIdSpinnerItem item;
            if (convertView != null) {
                item = (ViewIdSpinnerItem) convertView;
            } else {
                item = new ViewIdSpinnerItem(context);
                item.setTextSize(R.dimen.text_size_body_small);
            }
            item.setDropDown(isDropDownView);

            ViewBean view = views.get(position);
            item.setData(ViewBean.getViewTypeResId(view.type), view.id, isSelected);
            return item;
        }
    }

    private class GroupItem extends LinearLayout implements View.OnClickListener {

        private TextView title;

        public GroupItem(Context context) {
            super(context);
            initialize(context);
        }

        private void initialize(Context context) {
            ViewUtil.inflateLayoutInto(context, this, R.layout.property_group_item);
            title = findViewById(R.id.tv_title);
        }

        @Override
        public void onClick(View view) {
            selectedGroupId = (Integer) view.getTag();
            refreshPropertyGroups();
        }

        private void configure(int id, int labelResId) {
            setTag(id);
            title.setText(Helper.getResString(labelResId));
            setOnClickListener(this);
        }
    }

    private class SeeAllPropertiesFloatingItem extends LinearLayout implements View.OnClickListener {

        private final MaterialCardView propertyMenuItem;
        private final ImageView icon;
        private final TextView title;
        private ViewBean viewBean;

        public SeeAllPropertiesFloatingItem(Context context) {
            super(context);

            ViewUtil.inflateLayoutInto(context, this, R.layout.property_grid_item);
            propertyMenuItem = findViewById(R.id.property_menu_item);
            icon = findViewById(R.id.img_icon);
            title = findViewById(R.id.tv_title);
        }

        @Override
        public void onClick(View v) {
            if (propertyListener != null) {
                propertyListener.onPropertyRequested(projectFile.getXmlName(), viewBean);
            }
        }

        private void configure(int imageResId, int propertyNameResId) {
            propertyMenuItem.setVisibility(VISIBLE);
            propertyMenuItem.setCardBackgroundColor(MaterialColors.getColor(this, R.attr.colorPrimaryContainer));
            propertyMenuItem.setOnClickListener(this);
            icon.setImageResource(imageResId);
            icon.setColorFilter(MaterialColors.getColor(this, R.attr.colorOnPrimaryContainer), PorterDuff.Mode.SRC_ATOP);
            title.setText(Helper.getResString(propertyNameResId));
            title.setTextColor(MaterialColors.getColor(this, R.attr.colorOnPrimaryContainer));
        }

        private void setView(ViewBean viewBean) {
            this.viewBean = viewBean;
        }
    }
}
