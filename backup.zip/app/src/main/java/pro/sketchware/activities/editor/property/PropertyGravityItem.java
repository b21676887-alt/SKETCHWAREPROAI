package pro.sketchware.activities.editor.property;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.Gravity;
import android.view.View;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.google.android.material.dialog.MaterialAlertDialogBuilder;

import pro.sketchware.core.callback.PropertyChangedCallback;
import pro.sketchware.util.UIHelper;
import pro.sketchware.core.project.SketchwareConstants;
import pro.sketchware.util.ViewUtil;
import pro.sketchware.util.Helper;
import pro.sketchware.R;

@SuppressLint("ViewConstructor")
public class PropertyGravityItem extends RelativeLayout implements View.OnClickListener {

    private String key = "";
    private int gravityValue = -1;
    private TextView tvName;
    private TextView tvValue;
    private ImageView imgLeftIcon;
    private int icon;
    private View propertyItem;
    private View propertyMenuItem;
    private PropertyChangedCallback valueChangeListener;

    public PropertyGravityItem(Context context, boolean useAttrs) {
        super(context);
        initialize(context, useAttrs);
    }

    public String getKey() {
        return key;
    }

    public void setKey(String propertyKey) {
        key = propertyKey;
        int identifier = getResources().getIdentifier(propertyKey, "string", getContext().getPackageName());
        if (identifier > 0) {
            tvName.setText(Helper.getResString(identifier));
            icon = R.drawable.ic_mtrl_center;
            if (propertyMenuItem.getVisibility() == VISIBLE) {
                ((ImageView) findViewById(R.id.img_icon)).setImageResource(icon);
                ((TextView) findViewById(R.id.tv_title)).setText(Helper.getResString(identifier));
                return;
            }
            imgLeftIcon.setImageResource(icon);
        }
    }

    public int getValue() {
        return gravityValue;
    }

    public void setValue(int value) {
        gravityValue = value;
        tvValue.setText(SketchwareConstants.gravityToString(value));
    }

    @Override
    public void onClick(View v) {
        if (!UIHelper.isClickThrottled()) {
            switch (key) {
                case "property_gravity":
                case "property_layout_gravity":
                    showDialog();
                    break;
            }
        }
    }

    public void setOnPropertyValueChangeListener(PropertyChangedCallback onPropertyValueChangeListener) {
        valueChangeListener = onPropertyValueChangeListener;
    }

    public void setOrientationItem(int orientationItem) {
        if (orientationItem == 0) {
            propertyItem.setVisibility(GONE);
            propertyMenuItem.setVisibility(VISIBLE);
            propertyItem.setOnClickListener(null);
            propertyMenuItem.setOnClickListener(this);
        } else {
            propertyItem.setVisibility(VISIBLE);
            propertyMenuItem.setVisibility(GONE);
            propertyItem.setOnClickListener(this);
            propertyMenuItem.setOnClickListener(null);
        }
    }

    private void initialize(Context context, boolean useAttrs) {
        ViewUtil.inflateLayoutInto(context, this, R.layout.property_selector_item);
        tvName = findViewById(R.id.tv_name);
        tvValue = findViewById(R.id.tv_value);
        imgLeftIcon = findViewById(R.id.img_left_icon);
        propertyItem = findViewById(R.id.property_item);
        propertyMenuItem = findViewById(R.id.property_menu_item);
//        if (z) {
//            propertyMenuItem.setOnClickListener(this);
//            propertyMenuItem.setSoundEffectsEnabled(true);
//        }
    }

    private void showDialog() {
        MaterialAlertDialogBuilder dialog = new MaterialAlertDialogBuilder(getContext());
        dialog.setTitle(Helper.getText(tvName));
        dialog.setIcon(icon);

        View view = ViewUtil.inflateLayout(getContext(), R.layout.property_popup_selector_gravity);
        CheckBox chk_left = view.findViewById(R.id.chk_left);
        CheckBox chk_right = view.findViewById(R.id.chk_right);
        CheckBox chk_hcenter = view.findViewById(R.id.chk_hcenter);
        CheckBox chk_top = view.findViewById(R.id.chk_top);
        CheckBox chk_bottom = view.findViewById(R.id.chk_bottom);
        CheckBox chk_vcenter = view.findViewById(R.id.chk_vcenter);
        CheckBox chk_center = view.findViewById(R.id.chk_center);

        if (gravityValue == Gravity.CENTER) {
            chk_center.setChecked(true);
        } else {
            int verticalGravity = gravityValue & Gravity.FILL_VERTICAL;
            int horizontalGravity = gravityValue & Gravity.FILL_HORIZONTAL;

            if (horizontalGravity == Gravity.CENTER_HORIZONTAL) {
                chk_hcenter.setChecked(true);
            } else {
                if ((horizontalGravity & Gravity.LEFT) == Gravity.LEFT) {
                    chk_left.setChecked(true);
                }
                if ((horizontalGravity & Gravity.RIGHT) == Gravity.RIGHT) {
                    chk_right.setChecked(true);
                }
            }
            if (verticalGravity == Gravity.CENTER_VERTICAL) {
                chk_vcenter.setChecked(true);
            } else {
                if ((verticalGravity & Gravity.TOP) == Gravity.TOP) {
                    chk_top.setChecked(true);
                }
                if ((verticalGravity & Gravity.BOTTOM) == Gravity.BOTTOM) {
                    chk_bottom.setChecked(true);
                }
            }
        }

        dialog.setView(view);

        dialog.setPositiveButton(Helper.getResString(R.string.common_word_select), (v, which) -> {
            int value = Gravity.NO_GRAVITY;

            if (chk_center.isChecked()) {
                value = Gravity.CENTER;
            } else {
                if (chk_left.isChecked()) {
                    value |= Gravity.LEFT;
                }
                if (chk_right.isChecked()) {
                    value |= Gravity.RIGHT;
                }
                if (chk_hcenter.isChecked()) {
                    value |= Gravity.CENTER_HORIZONTAL;
                }
                if (chk_top.isChecked()) {
                    value |= Gravity.TOP;
                }
                if (chk_bottom.isChecked()) {
                    value |= Gravity.BOTTOM;
                }
                if (chk_vcenter.isChecked()) {
                    value |= Gravity.CENTER_VERTICAL;
                }
            }
            setValue(value);
            if (valueChangeListener != null) {
                valueChangeListener.onPropertyChanged(key, gravityValue);
            }
            v.dismiss();
        });
        dialog.setNegativeButton(Helper.getResString(R.string.common_word_cancel), null);
        dialog.show();
    }
}
