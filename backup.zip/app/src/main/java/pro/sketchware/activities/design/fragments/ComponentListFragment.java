package pro.sketchware.activities.design.fragments;


import pro.sketchware.util.Helper;
import android.content.Intent;
import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.ConcatAdapter;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.ListAdapter;
import androidx.recyclerview.widget.RecyclerView;
import androidx.lifecycle.ViewModelProvider;

import pro.sketchware.beans.ComponentBean;
import pro.sketchware.beans.EventBean;
import pro.sketchware.beans.ProjectFileBean;
import pro.sketchware.activities.design.DesignEditorViewModel;
import pro.sketchware.activities.editor.LogicEditorActivity;
import pro.sketchware.activities.editor.component.AddComponentBottomSheet;
import pro.sketchware.activities.editor.component.ComponentEventButton;
import pro.sketchware.widgets.base.CollapsibleViewHolder;
import pro.sketchware.widgets.CollapsibleButton;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Set;

import pro.sketchware.R;
import pro.sketchware.databinding.FrComponentListBinding;
import pro.sketchware.databinding.FrLogicListItemComponentBinding;
import pro.sketchware.databinding.FrLogicListItemEventPreviewBinding;
import pro.sketchware.core.codegen.EventRegistry;
import pro.sketchware.util.SketchToast;
import pro.sketchware.util.UIHelper;
import pro.sketchware.util.ViewUtil;

public class ComponentListFragment extends DesignProjectFragment implements View.OnClickListener {

    private ProjectFileBean projectFile;
    private Adapter adapter;
    private String sc_id;
    private ArrayList<ComponentBean> components = new ArrayList<>();

    private FrComponentListBinding binding;

    public static ComponentListFragment newInstance(String projectId) {
        ComponentListFragment fragment = new ComponentListFragment();
        fragment.setArguments(projectArguments(projectId));
        return fragment;
    }

    public void refreshData() {
        if (projectFile != null && adapter != null) {
            components = projectData().getComponents(projectFile.getJavaName());
            adapter.notifyDataSetChanged();
        }
    }

    @Override
    public void onClick(View v) {
        if (!UIHelper.isClickThrottled() && v.getId() == binding.fab.getId()) {
            AddComponentBottomSheet addComponentBottomSheet = AddComponentBottomSheet.newInstance(sc_id, projectFile, () -> refreshData());
            addComponentBottomSheet.show(getParentFragmentManager(), null);
        }
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        sc_id = requireProjectId();
        binding = FrComponentListBinding.inflate(inflater, container, false);
        initialize();
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        new ViewModelProvider(requireActivity())
                .get(DesignEditorViewModel.class)
                .activeProjectFile()
                .observe(getViewLifecycleOwner(), projectFile -> {
                    if (projectFile != null) {
                        setProjectFile(projectFile);
                        refreshData();
                    }
                });
    }

    public void unselectAll() {
        if (projectFile != null) {
            for (ComponentBean component : projectData().getComponents(projectFile.getJavaName())) {
                component.initValue();
            }
            adapter.notifyDataSetChanged();
        }
    }

    private void initialize() {
        binding.componentList.setHasFixedSize(true);
        binding.emptyMessage.setVisibility(View.GONE);
        binding.emptyMessage.setText(R.string.component_message_no_components);
        binding.componentList.setLayoutManager(new LinearLayoutManager(requireContext(), RecyclerView.VERTICAL, false));
        adapter = new Adapter();
        binding.componentList.setAdapter(adapter);
        binding.fab.setOnClickListener(this);
    }

    private void setProjectFile(ProjectFileBean projectFileBean) {
        projectFile = projectFileBean;
    }

    private void openEvent(String targetId, String eventName, String eventText) {
        Intent intent = new Intent(requireActivity().getApplicationContext(), LogicEditorActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
        intent.putExtra("sc_id", sc_id);
        intent.putExtra("id", targetId);
        intent.putExtra("event", eventName);
        intent.putExtra("project_file", projectFile);
        intent.putExtra("event_text", eventText);
        startActivity(intent);
    }

    private class Adapter extends RecyclerView.Adapter<Adapter.ViewHolder> {
        private static final ConcatAdapter.Config EVENTS_ADAPTER_CONFIG = new ConcatAdapter.Config.Builder()
                .setIsolateViewTypes(false)
                .build();
        private final RecyclerView.RecycledViewPool eventViewHolders = new RecyclerView.RecycledViewPool();

        @Override
        public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
            ComponentBean componentBean = components.get(position);
            holder.bind(componentBean);
        }

        @Override
        @NonNull
        public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            return new ViewHolder(FrLogicListItemComponentBinding.inflate(LayoutInflater.from(parent.getContext()), parent, false));
        }

        @Override
        public int getItemCount() {
            int size = components.size();
            if (size == 0) {
                binding.emptyMessage.setVisibility(View.VISIBLE);
            } else {
                binding.emptyMessage.setVisibility(View.GONE);
            }
            return size;
        }

        private class ViewHolder extends CollapsibleViewHolder {

            public final FrLogicListItemComponentBinding binding;

            public ViewHolder(FrLogicListItemComponentBinding itemBinding) {
                super(itemBinding.getRoot(), 200);
                binding = itemBinding;
            }

            void bind(ComponentBean componentBean) {
                binding.componentOption
                        .getDeleteButton()
                        .getLabel()
                        .setText(R.string.component_context_menu_title_delete_component);
                binding.componentOption.setButtonOnClickListener(v -> {
                    int lastSelectedItem = getLayoutPosition();
                    if (lastSelectedItem == RecyclerView.NO_POSITION) return;
                    ComponentBean bean =
                            projectData().getComponent(projectFile.getJavaName(), lastSelectedItem);
                    if (v instanceof CollapsibleButton) {
                        bean.isConfirmation = true;
                        setAnimateNextTransformation(true);
                        notifyItemChanged(lastSelectedItem);
                    } else {
                        int id = v.getId();
                        if (id == R.id.confirm_no) {
                            bean.isConfirmation = false;
                            setAnimateNextTransformation(true);
                            notifyItemChanged(lastSelectedItem);
                        } else if (id == R.id.confirm_yes) {
                            projectData().removeComponent(projectFile.getJavaName(), bean);
                            bean.isConfirmation = false;
                            notifyItemRemoved(lastSelectedItem);
                            notifyItemRangeChanged(lastSelectedItem, getItemCount());
                        }
                    }
                });
                onDoneInitializingViews();
                setOnClickCollapseConfig(v -> v != binding.getRoot());
                binding.componentEvents.setRecycledViewPool(eventViewHolders);
                if (binding.componentEvents.getLayoutManager()
                        instanceof LinearLayoutManager manager) {
                    manager.setRecycleChildrenOnDetach(true);
                }
                binding.componentEvents.setItemAnimator(null);
                AddedEventsAdapter addedEventsAdapter = new AddedEventsAdapter();
                AvailableEventsAdapter availableEventsAdapter = new AvailableEventsAdapter();
                availableEventsAdapter.setOnEventClickListener(event -> {
                    var newAddedEvents = new ArrayList<>(addedEventsAdapter.getCurrentList());
                    newAddedEvents.add(event);
                    addedEventsAdapter.submitList(newAddedEvents);
                    var newAvailableEvents = new ArrayList<>(availableEventsAdapter.getCurrentList());
                    newAvailableEvents.remove(event.eventName);
                    availableEventsAdapter.submitList(newAvailableEvents);
                    openEvent(event.targetId, event.eventName, event.eventName);
                });
                ConcatAdapter componentEventsAdapter = new ConcatAdapter(
                        EVENTS_ADAPTER_CONFIG, addedEventsAdapter, availableEventsAdapter);

                binding.tvComponentType.setText(
                        ComponentBean.getComponentName(requireContext(), componentBean.type));
                binding.imgIcon.setImageResource(
                        ComponentBean.getIconResource(componentBean.type));

                switch (componentBean.type) {
                    case ComponentBean.COMPONENT_TYPE_SHAREDPREF -> binding.tvComponentId
                            .setText(componentBean.componentId + " : " + componentBean.param1);
                    case ComponentBean.COMPONENT_TYPE_FIREBASE,
                         ComponentBean.COMPONENT_TYPE_FIREBASE_STORAGE,
                         ComponentBean.COMPONENT_TYPE_FILE_PICKER -> {
                        String path = componentBean.param1;
                        if (path.isEmpty()) {
                            path = "/";
                        }
                        binding.tvComponentId.setText(componentBean.componentId + " : " + path);
                    }
                    default -> binding.tvComponentId.setText(componentBean.componentId);
                }

                ArrayList<EventBean> addedEvents =
                        projectData().getComponentEvents(projectFile.getJavaName(), componentBean);
                ArrayList<String> availableEvents =
                        new ArrayList<>(Arrays.asList(EventRegistry.getComponentEventsForClass(componentBean.getClassInfo())));

                binding.eventsPreview.removeAllViews();
                binding.eventsPreview.setAlpha(1.0f);
                binding.eventsPreview.setTranslationX(0.0f);
                if (componentBean.isCollapsed) {
                    binding.componentOptionLayout.setVisibility(View.GONE);
                    binding.imgMenu.setRotation(0.0f);
                } else {
                    binding.componentOptionLayout.setVisibility(View.VISIBLE);
                    binding.imgMenu.setRotation(-180.0f);
                    if (componentBean.isConfirmation) {
                        if (shouldAnimateNextTransformation()) {
                            binding.componentOption.showConfirmation();
                            setAnimateNextTransformation(false);
                        } else {
                            binding.componentOption.showConfirmationWithoutAnimation();
                        }
                    } else {
                        if (shouldAnimateNextTransformation()) {
                            binding.componentOption.hideConfirmation();
                            setAnimateNextTransformation(false);
                        } else {
                            binding.componentOption.hideConfirmationWithoutAnimation();
                        }
                    }
                }
                binding.componentOptionLayout.getLayoutParams().height =
                        ViewGroup.LayoutParams.WRAP_CONTENT;

                if (!addedEvents.isEmpty() || !availableEvents.isEmpty()) {
                    for (EventBean event : addedEvents) {
                        if (availableEvents.contains(event.eventName)) {
                            FrLogicListItemEventPreviewBinding previewBinding =
                                    FrLogicListItemEventPreviewBinding.inflate(LayoutInflater.from(requireContext()));

                            LinearLayout.LayoutParams layoutParams =
                                    new LinearLayout.LayoutParams(
                                            ViewGroup.LayoutParams.WRAP_CONTENT,
                                            ViewGroup.LayoutParams.WRAP_CONTENT);
                            layoutParams.setMargins(0, 0, (int) ViewUtil.dpToPx(requireContext(), 4.0f), 0);
                            previewBinding.getRoot().setLayoutParams(layoutParams);
                            previewBinding.icon.setImageResource(EventRegistry.getEventIconResource(event.eventName));
                            previewBinding.iconBg.setBackgroundResource(
                                    R.drawable.circle_bg_surface);
                            binding.eventsPreview.addView(previewBinding.getRoot());
                            availableEvents.remove(event.eventName);
                        }
                    }

                    for (String eventName : availableEvents) {
                        FrLogicListItemEventPreviewBinding previewBinding =
                                FrLogicListItemEventPreviewBinding.inflate(LayoutInflater.from(requireContext()));
                        LinearLayout.LayoutParams layoutParams2 =
                                new LinearLayout.LayoutParams(
                                        ViewGroup.LayoutParams.WRAP_CONTENT,
                                        ViewGroup.LayoutParams.WRAP_CONTENT);
                        layoutParams2.setMargins(0, 0, (int) ViewUtil.dpToPx(requireContext(), 4.0f), 0);
                        previewBinding.getRoot().setLayoutParams(layoutParams2);
                        previewBinding.icon.setImageResource(EventRegistry.getEventIconResource(eventName));
                        ColorMatrix colorMatrix = new ColorMatrix();
                        colorMatrix.setSaturation(0.0f);
                        previewBinding.icon.setColorFilter(new ColorMatrixColorFilter(colorMatrix));
                        binding.eventsPreview.addView(previewBinding.getRoot());
                        previewBinding.getRoot().setScaleX(0.8f);
                        previewBinding.getRoot().setScaleY(0.8f);
                    }

                    binding.componentEvents.setVisibility(View.VISIBLE);
                    if (!componentBean.isCollapsed) {
                        binding.eventsPreview.setTranslationX(
                                binding.eventsPreview.getWidth());
                        binding.eventsPreview.setAlpha(0);
                    }
                    addedEventsAdapter.submitList(addedEvents);
                    availableEventsAdapter.submitList(availableEvents);
                    binding.componentEvents.setAdapter(componentEventsAdapter);
                } else {
                    binding.componentEvents.setVisibility(View.GONE);
                }
            }

            @Override
            protected boolean isCollapsed() {
                return components.get(getLayoutPosition()).isCollapsed;
            }

            @Override
            protected void setIsCollapsed(boolean isCollapsed) {
                components.get(getLayoutPosition()).isCollapsed = isCollapsed;
            }

            @NonNull
            @Override
            protected ViewGroup getOptionsLayout() {
                return binding.componentOptionLayout;
            }

            @NonNull
            @Override
            protected Set<? extends View> getOnClickCollapseTriggerViews() {
                return Set.of(binding.imgMenu, binding.getRoot());
            }

            @NonNull
            @Override
            protected Set<? extends View> getOnLongClickCollapseTriggerViews() {
                return Set.of(binding.getRoot());
            }

            @Override
            public void collapse() {
                super.collapse();
                binding.eventsPreview.animate().translationX(0.0f).alpha(1.0f).setStartDelay(120L).setDuration(150L).start();
                binding.componentEvents.animate().translationX(-binding.componentEvents.getWidth()).setDuration(150L).alpha(0.0f).start();
            }

            @Override
            public void expand() {
                super.expand();
                binding.eventsPreview.animate().translationX(binding.eventsPreview.getWidth()).alpha(0.0f).setDuration(150L).start();
                binding.componentEvents.setTranslationX(-binding.componentEvents.getWidth());
                binding.componentEvents.setAlpha(0.0f);
                binding.componentEvents.animate().translationX(0.0f).setStartDelay(200L).setDuration(120L).alpha(1.0f).start();
            }

            private interface EventClickListener {
                void onEventClick(EventBean bean);
            }

            private class AddedEventsAdapter extends ListAdapter<EventBean, EventViewHolder> {
                private static final DiffUtil.ItemCallback<EventBean> DIFF_CALLBACK = new DiffUtil.ItemCallback<>() {
                    @Override
                    public boolean areItemsTheSame(@NonNull EventBean oldItem, @NonNull EventBean newItem) {
                        return oldItem.equals(newItem);
                    }

                    @Override
                    public boolean areContentsTheSame(@NonNull EventBean oldItem, @NonNull EventBean newItem) {
                        return true;
                    }
                };

                public AddedEventsAdapter() {
                    super(DIFF_CALLBACK);
                }

                @NonNull
                @Override
                public EventViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
                    ComponentEventButton button = new ComponentEventButton(parent.getContext());
                    return new EventViewHolder(button);
                }

                @Override
                public void onBindViewHolder(@NonNull EventViewHolder holder, int position) {
                    var event = getItem(position);
                    holder.button.onEventAdded();
                    holder.button.getName().setText(event.eventName);
                    holder.button.getIcon().setImageResource(EventRegistry.getEventIconResource(event.eventName));
                    holder.button.setClickListener(v -> {
                        if (!UIHelper.isClickThrottled()) {
                            openEvent(event.targetId, event.eventName, event.eventName);
                        }
                    });
                }
            }

            private class AvailableEventsAdapter extends ListAdapter<String, EventViewHolder> {
                private static final DiffUtil.ItemCallback<String> DIFF_CALLBACK = new DiffUtil.ItemCallback<>() {
                    @Override
                    public boolean areItemsTheSame(@NonNull String oldItem, @NonNull String newItem) {
                        return oldItem.equals(newItem);
                    }

                    @Override
                    public boolean areContentsTheSame(@NonNull String oldItem, @NonNull String newItem) {
                        return true;
                    }
                };
                private EventClickListener listener;

                public AvailableEventsAdapter() {
                    super(DIFF_CALLBACK);
                }

                public void setOnEventClickListener(EventClickListener listener) {
                    this.listener = listener;
                }

                @NonNull
                @Override
                public EventViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
                    ComponentEventButton button = new ComponentEventButton(parent.getContext());
                    return new EventViewHolder(button);
                }

                @Override
                public void onBindViewHolder(@NonNull EventViewHolder holder, int position) {
                    var eventName = getItem(position);
                    holder.button.onEventAvailableToAdd();
                    holder.button.getName().setText(eventName);
                    holder.button.getIcon().setImageResource(EventRegistry.getEventIconResource(eventName));
                    holder.button.setClickListener(v -> {
                        if (!UIHelper.isClickThrottled()) {
                            int componentPos = getLayoutPosition();
                            if (componentPos == RecyclerView.NO_POSITION) return;
                            var component = components.get(componentPos);
                            var event = new EventBean(EventBean.EVENT_TYPE_COMPONENT, component.type, component.componentId, eventName);
                            projectData().addEventBean(projectFile.getJavaName(), event);
                            SketchToast.toast(requireContext(), Helper.getResString(R.string.event_message_new_event), 0).show();
                            holder.button.onEventAdded();
                            if (listener != null) {
                                listener.onEventClick(event);
                            }
                        }
                    });
                }
            }

            private static class EventViewHolder extends RecyclerView.ViewHolder {
                public final ComponentEventButton button;

                public EventViewHolder(@NonNull ComponentEventButton itemView) {
                    super(itemView);
                    button = itemView;
                }
            }
        }
    }
}
