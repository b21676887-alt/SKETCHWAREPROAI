package pro.sketchware.activities.editor.view.palette;

import static pro.sketchware.util.SketchwareUtil.dpToPx;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import pro.sketchware.widgets.CustomScrollView;
import com.google.android.material.card.MaterialCardView;
import com.google.android.material.color.MaterialColors;

import java.util.HashMap;

import pro.sketchware.util.ViewUtil;
import pro.sketchware.activities.editor.view.palette.IconBadgeView;
import pro.sketchware.activities.editor.view.palette.IconBottomNavigationView;
import pro.sketchware.activities.editor.view.palette.IconCardView;
import pro.sketchware.activities.editor.view.palette.IconCircleImageView;
import pro.sketchware.activities.editor.view.palette.IconCodeView;
import pro.sketchware.activities.editor.view.palette.IconCollapsingToolbar;
import pro.sketchware.activities.editor.view.palette.IconGoogleSignInButton;
import pro.sketchware.activities.editor.view.palette.IconLottieAnimation;
import pro.sketchware.activities.editor.view.palette.IconMaterialButton;
import pro.sketchware.activities.editor.view.palette.IconOTPView;
import pro.sketchware.activities.editor.view.palette.IconPatternLockView;
import pro.sketchware.activities.editor.view.palette.IconRadioGroup;
import pro.sketchware.activities.editor.view.palette.IconRecyclerView;
import pro.sketchware.activities.editor.view.palette.IconSwipeRefreshLayout;
import pro.sketchware.activities.editor.view.palette.IconTabLayout;
import pro.sketchware.activities.editor.view.palette.IconTextInputLayout;
import pro.sketchware.activities.editor.view.palette.IconViewPager;
import pro.sketchware.activities.editor.view.palette.IconWaveSideBar;
import pro.sketchware.activities.editor.view.palette.IconYoutubePlayer;
import pro.sketchware.activities.editor.view.palette.IconAnalogClock;
import pro.sketchware.activities.editor.view.palette.IconAutoCompleteTextView;
import pro.sketchware.activities.editor.view.palette.IconDatePicker;
import pro.sketchware.activities.editor.view.palette.IconDigitalClock;
import pro.sketchware.activities.editor.view.palette.IconGridView;
import pro.sketchware.activities.editor.view.palette.IconMultiAutoCompleteTextView;
import pro.sketchware.activities.editor.view.palette.IconRadioButton;
import pro.sketchware.activities.editor.view.palette.IconRatingBar;
import pro.sketchware.activities.editor.view.palette.IconSearchView;
import pro.sketchware.activities.editor.view.palette.IconTimePicker;
import pro.sketchware.activities.editor.view.palette.IconVideoView;
import pro.sketchware.util.Helper;
import pro.sketchware.R;
import pro.sketchware.widgets.IconCustomWidget;

public class PaletteWidget extends LinearLayout {

    public MaterialCardView cardView;
    public MaterialCardView aicardView;
    private LinearLayout layoutContainer;
    private LinearLayout widgetsContainer;
    private TextView titleLayouts;
    private TextView titleWidgets;
    private CustomScrollView scrollView;

    public PaletteWidget(Context context) {
        super(context);
        initialize(context);
    }

    public PaletteWidget(Context context, AttributeSet attrs) {
        super(context, attrs);
        initialize(context);
    }

    public void addCustomWidgets(View view) {
        layoutContainer.addView(view);
    }

    public View customWidget(HashMap<String, Object> map) {
        Object titleObj = map.get("title");
        Object nameObj = map.get("name");
        String title = titleObj != null ? titleObj.toString() : "";
        String name = nameObj != null ? nameObj.toString() : "";
        if ("Layouts".equals(String.valueOf(map.get("Class")))) {
            LinearLayout iconBase;
            Context context = getContext();
            iconBase = new IconCustomWidget(map, context);
            layoutContainer.addView(iconBase);
            return iconBase;
        } else {
            IconBase iconBase;
            Context context = getContext();
            iconBase = new IconCustomWidget(map, context);
            iconBase.setText(title);
            iconBase.setName(name);
            if ("AndroidX".equals(String.valueOf(map.get("Class")))) {
                layoutContainer.addView(iconBase);
            } else {
                widgetsContainer.addView(iconBase);
            }
            return iconBase;
        }
    }

    public View addLayout(PaletteWidget.LayoutType layoutType, String tag) {
        LinearLayout layout = switch (layoutType) {
            case a -> new IconLinearHorizontal(getContext());
            case b -> new IconLinearVertical(getContext());
            case c -> new IconScrollViewHorizontal(getContext());
            case d -> new IconScrollViewVertical(getContext());
        };

        if (tag != null && !tag.isEmpty()) {
            layout.setTag(tag);
        }

        layoutContainer.addView(layout);
        return layout;
    }

    public View addWidget(PaletteWidget.WidgetType widgetType, String tag, String text, String resourceName) {
        IconBase iconBase;
        switch (widgetType) {
            case a -> iconBase = new IconButton(getContext());
            case c -> iconBase = new IconEditText(getContext());
            case b -> iconBase = new IconTextView(getContext());
            case d -> {
                iconBase = new IconImageView(getContext());
                ((IconImageView) iconBase).setResourceName(resourceName);
            }
            case e -> iconBase = new IconListView(getContext());
            case f -> iconBase = new IconSpinner(getContext());
            case g -> iconBase = new IconCheckBox(getContext());
            case h -> iconBase = new IconWebView(getContext());
            case i -> iconBase = new IconSwitch(getContext());
            case j -> iconBase = new IconSeekBar(getContext());
            case k -> iconBase = new IconCalendarView(getContext());
            case l -> iconBase = new IconAdView(getContext());
            case m -> iconBase = new IconProgressBar(getContext());
            case n -> iconBase = new IconMapView(getContext());
            default -> iconBase = new IconBase(getContext());
        }

        if (tag != null && !tag.isEmpty()) {
            iconBase.setTag(tag);
        }

        iconBase.setText(text);
        iconBase.setName(resourceName);
        widgetsContainer.addView(iconBase);
        return iconBase;
    }

    public void removeWidgetLayouts() {
        layoutContainer.removeAllViews();
    }

    private void initialize(Context context) {
        ViewUtil.inflateLayoutInto(context, this, R.layout.palette_widget);
        layoutContainer = findViewById(R.id.layout);
        widgetsContainer = findViewById(R.id.widget);
        titleLayouts = findViewById(R.id.tv_layout);
        titleWidgets = findViewById(R.id.tv_widget);
        titleLayouts.setText(Helper.getResString(R.string.view_panel_title_layouts));
        titleWidgets.setText(Helper.getResString(R.string.view_panel_title_widgets));
        scrollView = findViewById(R.id.scv);
        cardView = findViewById(R.id.cardView);
        aicardView = findViewById(R.id.aicardView);
    }

    public void removeWidgets() {
        widgetsContainer.removeAllViews();
    }

    public void extraTitle(String title, int targetType) {
        LinearLayout target = targetType == 0 ? layoutContainer : widgetsContainer;

        TextView titleView = new TextView(getContext());
        LayoutParams layoutParams = new LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        layoutParams.setMargins(dpToPx(4), dpToPx(4), dpToPx(4), dpToPx(4));
        titleView.setLayoutParams(layoutParams);
        titleView.setText(title);
        titleView.setTextSize(12);
        titleView.setTextColor(MaterialColors.getColor(titleView, R.attr.colorPrimary));
        target.addView(titleView);
    }

    public View extraWidget(String tag, String title, String name) {
        IconBase iconBase;
        Context context = getContext();
        iconBase = switch (title) {
            case "DatePicker" -> new IconDatePicker(context);
            case "RatingBar" -> new IconRatingBar(context);
            case "SearchView" -> new IconSearchView(context);
            case "DigitalClock" -> new IconDigitalClock(context);
            case "RadioButton" -> new IconRadioButton(context);
            case "GridView" -> new IconGridView(context);
            case "AutoCompleteTextView" -> new IconAutoCompleteTextView(context);
            case "MultiAutoCompleteTextView" -> new IconMultiAutoCompleteTextView(context);
            case "VideoView" -> new IconVideoView(context);
            case "TimePicker" -> new IconTimePicker(context);
            case "AnalogClock" -> new IconAnalogClock(context);
            case "ViewPager" -> new IconViewPager(context);
            case "BadgeView" -> new IconBadgeView(context);
            case "PatternLockView" -> new IconPatternLockView(context);
            case "WaveSideBar" -> new IconWaveSideBar(context);
            case "SignInButton" -> new IconGoogleSignInButton(context);
            case "MaterialButton" -> new IconMaterialButton(context);
            case "CircleImageView" -> new IconCircleImageView(context);
            case "LottieAnimation" -> new IconLottieAnimation(context);
            case "YoutubePlayer" -> new IconYoutubePlayer(context);
            case "OTPView" -> new IconOTPView(context);
            case "CodeView" -> new IconCodeView(context);
            case "RecyclerView" -> new IconRecyclerView(context);
            default -> new IconBase(context);
        };
        if (tag != null && !tag.isEmpty()) {
            iconBase.setTag(tag);
        }

        iconBase.setText(title);
        iconBase.setName(name);
        widgetsContainer.addView(iconBase);
        return iconBase;
    }

    public View extraWidgetLayout(String tag, String name) {
        IconBase iconBase;
        Context context = getContext();
        iconBase = switch (name) {
            case "TabLayout" -> new IconTabLayout(context);
            case "BottomNavigationView" -> new IconBottomNavigationView(context);
            case "CollapsingToolbarLayout" -> new IconCollapsingToolbar(context);
            case "SwipeRefreshLayout" -> new IconSwipeRefreshLayout(context);
            case "RadioGroup" -> new IconRadioGroup(context);
            case "CardView" -> new IconCardView(context);
            case "TextInputLayout" -> new IconTextInputLayout(context);
            case "RelativeLayout" -> new IconRelativeLayout(context);
            default -> new IconBase(context);
        };
        if (tag != null && !tag.isEmpty()) {
            iconBase.setTag(tag);
        }

        layoutContainer.addView(iconBase);
        return iconBase;
    }

    public void setLayoutVisible(int visibility) {
        layoutContainer.setVisibility(visibility);
        titleLayouts.setVisibility(visibility);
    }

    public void setScrollEnabled(boolean scrollEnabled) {
        if (scrollEnabled) {
            scrollView.enableScroll();
        } else {
            scrollView.disableScroll();
        }
    }

    public void setWidgetVisible(int visibility) {
        widgetsContainer.setVisibility(visibility);
        titleWidgets.setVisibility(visibility);
    }

    public enum LayoutType {
        a, //eLinearHorizontal
        b, //eLinearVertical
        c, //eScrollHorizontal
        d //eScrollVertical
    }

    public enum WidgetType {
        a, //eButton
        b, //eTextView
        c, //eEditText
        d, //eImageView
        e, //eListView
        f, //eSpinner
        g, //eCheckBox
        h, //eWebView
        i, //eSwitch
        j, //eSeekBar
        k, //eCalenderView
        l, //eAddView
        m, //eProgressBar
        n, //eMapView
        o //eRadioButton
    }
}
