package pro.sketchware.activities.editor.view;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.util.AttributeSet;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;

import pro.sketchware.core.block.view.BlockView;
import pro.sketchware.util.ViewUtil;
import pro.sketchware.R;

public class ViewDummy extends RelativeLayout {
    public ImageView img_notallowed;
    public ImageView img_dummy;
    public LinearLayout layout_dummy;
    public int[] sourceLocation;
    public int[] dummyLocation;
    public boolean allowed;

    public ViewDummy(Context context) {
        super(context);
        sourceLocation = new int[2];
        dummyLocation = new int[2];
        allowed = false;
        initialize(context);
    }

    public ViewDummy(Context context, AttributeSet attrs) {
        super(context, attrs);
        sourceLocation = new int[2];
        dummyLocation = new int[2];
        allowed = false;
        initialize(context);
    }

    public final void initialize(Context context) {
        ViewUtil.inflateLayoutInto(context, this, R.layout.dummy);
        img_notallowed = findViewById(R.id.img_notallowed);
        img_dummy = findViewById(R.id.img_dummy);
        layout_dummy = findViewById(R.id.layout_dummy);
    }

    public void captureViewBitmap(View view) {
        Bitmap bitmap = createBitmapOfView(view);
        view.getLocationOnScreen(sourceLocation);
        img_dummy.setImageBitmap(bitmap);
        img_dummy.setAlpha(0.5f);
    }

    public boolean getAllow() {
        return allowed;
    }

    public void setAllow(boolean allowed) {
        this.allowed = allowed;
        if (allowed) {
            img_notallowed.setVisibility(View.INVISIBLE);
        } else {
            img_notallowed.setVisibility(View.VISIBLE);
        }
    }

    public void setDummyVisibility(int visibility) {
        layout_dummy.setVisibility(visibility);
    }

    public final Bitmap createBitmapOfView(View view) {
        Bitmap bitmap = Bitmap.createBitmap(view.getMeasuredWidth(), view.getMeasuredHeight(), Bitmap.Config.ARGB_8888);
        view.draw(new Canvas(bitmap));
        return bitmap;
    }

    public void setBlockTypeImage(BlockView rs) {
        switch (rs.blockType) {
            case "b":
                img_dummy.setImageResource(R.drawable.selected_block_boolean);
                break;
            case "d":
            case "n":
                img_dummy.setImageResource(R.drawable.selected_block_integer);
                break;
            case "s", "v", "p", "l", "a":
                img_dummy.setImageResource(R.drawable.selected_block_string);
                break;
            case "c":
                img_dummy.setImageResource(R.drawable.selected_block_loop);
                break;
            case "e":
                img_dummy.setImageResource(R.drawable.selected_block_ifelse);
                break;
            case "f":
                img_dummy.setImageResource(R.drawable.selected_block_final);
                break;
            default:
                img_dummy.setImageResource(R.drawable.selected_block_command);
                break;
        }
        img_dummy.setAlpha(0.5f);
        rs.getLocationOnScreen(sourceLocation);
    }

    public void updateDummyPosition(View view, float touchX, float touchY, float offsetX, float offsetY, float extraOffsetX, float extraOffsetY) {
        if (layout_dummy.getVisibility() != View.VISIBLE) {
            setDummyVisibility(View.VISIBLE);
        }
        getLocationOnScreen(dummyLocation);
        layout_dummy.setX((sourceLocation[0] - dummyLocation[0]) + touchX - offsetX - img_notallowed.getWidth() + extraOffsetX);
        layout_dummy.setY((sourceLocation[1] - dummyLocation[1]) + touchY - offsetY + extraOffsetY);
    }

    public void updateDummyPosition(View view, float touchX, float touchY, float offsetX, float offsetY) {
        updateDummyPosition(view, touchX, touchY, offsetX, offsetY, 0.0f, 0.0f);
    }

    public void getDummyLocation(int[] location) {
        img_dummy.getLocationOnScreen(location);
    }
}
